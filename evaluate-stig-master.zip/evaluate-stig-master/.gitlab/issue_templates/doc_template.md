## Proposal 

(Detailed thoughts on implementation and design)

/label ~"type: documentation"
/label ~"status: triage"
