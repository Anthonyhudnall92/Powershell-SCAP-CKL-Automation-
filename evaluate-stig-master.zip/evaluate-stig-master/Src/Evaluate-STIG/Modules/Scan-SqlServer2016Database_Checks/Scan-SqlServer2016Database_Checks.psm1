##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     MS SQL Server 2016 Database
# Version:  V2R5
# Class:    UNCLASSIFIED
# Updated:  11/2/2022
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Get-V213900 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213900
        STIG ID    : SQL6-D0-000100
        Rule ID    : SV-213900r822444_rule
        CCI ID     : CCI-000015
        Rule Name  : SRG-APP-000023-DB-000001
        Rule Title : SQL Server databases must integrate with an organization-level authentication/access mechanism providing account management and automation for all users, groups, roles, and any other principals.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $in = Get-isql -ServerInstance $Instance -Database $Database "select @@servername"
    if ($in) {
        foreach ($h in $in.column1) {
            $res = Get-ISQL -ServerInstance $h "EXEC sp_configure 'contained database authentication'"
            if ($res.run_value -eq 1 -or $res.config_value -eq 1) {
                $FindingDetails += "Instance $h is using contained database authentication.`n"

            $res = Get-ISQL -ServerInstance $h "
            SELECT CASE SERVERPROPERTY('IsIntegratedSecurityOnly')
            WHEN 1 THEN 'Windows Authentication'
            WHEN 0 THEN 'Windows and SQL Server Authentication'
            END as AuthenticationMode
        "
            if ($res.AuthenticationMode -ne 'Windows Authentication') {
                $FindingDetails += "Instance $h's login authentication mode is $($res.AuthenticationMode) instead of Windows Authentication.`n"
            }

            }

        } # foreach
        if ($FindingDetails -gt "") {
            $Status = 'Open'
            $FindingDetails += "DBA, ensure the above are documented as authorized in the server documentation.`n"
            $res = Get-isql -ServerInstance $Instance -Database $Database "
            select @@servername, name
            from sys.database_principals
            WHERE type_desc = 'SQL_USER'
            AND authentication_type_desc = 'DATABASE'
        "
            if ($res) {
                $FindingDetails += "DBA, also ensure the following accounts are authorized in the server documentation to be managed by SQL Server:`n$($res | Format-Table -AutoSize| Out-String)"
            } # if ($res)
        } else {
            $Status = "NotAFinding"
            $FindingDetails += "Enabled Contained Databases is set to false"
        }
    }
    else {
        $Status = "NotAFinding"
        $FindingDetails = "No active SQL instances currently exist on this host."
    } # if ($in)

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "Windows Authentication is used."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213901 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213901
        STIG ID    : SQL6-D0-000300
        Rule ID    : SV-213901r822446_rule
        CCI ID     : CCI-000213
        Rule Name  : SRG-APP-000033-DB-000084
        Rule Title : SQL Server must enforce approved authorizations for logical access to information and system resources in accordance with applicable access control policies.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    If ($Database -eq "tempdb") {
        $Status = "Not_Applicable"
        $FindingDetails += "This is the '$Database' database so this requirement is NA."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213902 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213902
        STIG ID    : SQL6-D0-000400
        Rule ID    : SV-213902r508025_rule
        CCI ID     : CCI-000166
        Rule Name  : SRG-APP-000080-DB-000063
        Rule Title : SQL Server must protect against a user falsely repudiating by ensuring only clearly unique Active Directory user accounts can connect to the database.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as Instance
            , db_name() as DatabaseName
            , name as UserName
        FROM sys.database_principals
        WHERE type in ('U','G')
        AND name LIKE '%$'
    "
    if ($res) {
        $done = @{}
        $res | ForEach-Object {
            $sUID = $_.username
            if (! $done[$sUID]) {
                $sInst = $_.Instance
                $done[$sUID] = 'y'
                $sShortUID = $sUID -replace '^.*\\'
                if (([ADSISearcher]"(&(ObjectCategory=Computer)(Name=$sShortUID))").FindAll()) {
                    $listDB = ($res | Where-Object { $_.username -eq $sUID }).databasename -join ','
                    $FindingDetails += "User $sUID on instance $sInst, database $listDB cannot be traced to a specific user or process and should be removed."
                } # if (([ADSISearcher...
            } # if (! $done[$sUID])
        } # $res | foreach-object
    } # if ($res)
    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "The check query returned no results."
    }
    else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213903 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213903
        STIG ID    : SQL6-D0-000500
        Rule ID    : SV-213903r508025_rule
        CCI ID     : CCI-000166
        Rule Name  : SRG-APP-000080-DB-000063
        Rule Title : SQL Server must protect against a user falsely repudiating by use of system-versioned tables (Temporal Tables).
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT SCHEMA_NAME(T.schema_id) AS schema_name, T.name AS table_name, T.temporal_type_desc, SCHEMA_NAME(H.schema_id) + '.' + H.name AS history_table
        FROM sys.tables T
        JOIN sys.tables H ON T.history_table_id = H.object_id
        WHERE T.temporal_type != 0
        ORDER BY schema_name, table_name
    "
    if ($res) {
        $FindingDetails += "DBA, Using the system documentation, determine which tables are required to be temporal tables." 
        $FindingDetails += "If any tables listed in the documentation are not in this list, this is a finding.:`n$($res | Format-Table -AutoSize| Out-String)"
    } else {
        $FindingDetails += "No results were returned by the check query."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213904 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213904
        STIG ID    : SQL6-D0-000600
        Rule ID    : SV-213904r508025_rule
        CCI ID     : CCI-000166
        Rule Name  : SRG-APP-000080-DB-000063
        Rule Title : SQL Server must protect against a user falsely repudiating by ensuring databases are not in a trust relationship.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@SERVERNAME               as InstanceName
            , DB_NAME()                  AS [Database]
            , SUSER_SNAME(d.owner_sid)   AS DatabaseOwner
            , CASE
                WHEN role.name IN ('sysadmin','securityadmin')
                OR permission.permission_name = 'CONTROL SERVER'
                THEN 'YES'
                ELSE 'No'
            END AS 'IsOwnerPrivileged'
        FROM sys.databases d
        LEFT JOIN sys.server_principals login ON d.owner_sid = login.sid
        LEFT JOIN sys.server_role_members rm ON login.principal_id = rm.member_principal_id
        LEFT JOIN sys.server_principals role ON rm.role_principal_id = role.principal_id
        LEFT JOIN sys.server_permissions permission ON login.principal_id = permission.grantee_principal_id
        WHERE d.name = DB_NAME()
        AND DB_NAME() <> 'msdb'
        AND D.is_trustworthy_on = 1
    "
    if (!$res) {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check query."
    }
    else {
        $FindingDetails = "DBA, Confirm that an approved server documentation documents the need for TRUSTWORTHY in the following:$($res | Format-Table | Out-String)"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213905 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213905
        STIG ID    : SQL6-D0-000700
        Rule ID    : SV-213905r508025_rule
        CCI ID     : CCI-000171
        Rule Name  : SRG-APP-000090-DB-000065
        Rule Title : SQL Server must allow only the ISSM (or individuals or roles appointed by the ISSM) to select which auditable events are to be audited.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    # Check for accounts with the db_owner role...
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT
        R.name AS role_name,
        RM.name AS role_member_name,
        RM.type_desc
        FROM sys.database_principals R
        JOIN sys.database_role_members DRM ON
        R.principal_id = DRM.role_principal_id
        JOIN sys.database_principals RM ON
        DRM.member_principal_id = RM.principal_id
        WHERE R.type = 'R'
        AND R.name = 'db_owner'
        and rm.name != 'dbo' -- this deviates from the STIG check
        ORDER BY role_member_name
    " | Sort-Object -Unique role_member_name
    if ($res) {
        $FindingDetails += "DBA, Confirm that an approved server documentation documents the following accounts as authorized to act as database owners:`n$($res | Format-Table | Out-String)"
        <# possible future format, but needs testing
        ForEach ($obj in $res){
        $FindingDetails += "`tRole Name:`t`t$($obj.role_name)" | Out-String
        $FindingDetails += "`tRole Member Name:`t$($obj.role_member_name)" | Out-String
        $FindingDetails += "`tType Description:`t$($obj.'RM.type_desc')" | Out-String
        $FindingDetails += "" | Out-String
    }
    #>
    }

    # Check for accounts with the CONTROL or ALTER ANY DATABASE AUDIT privileges...
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT
        PERM.permission_name,
        DP.name AS principal_name,
        DP.type_desc AS principal_type,
        DBRM.role_member_name
        FROM sys.database_permissions PERM
        JOIN sys.database_principals DP ON PERM.grantee_principal_id = DP.principal_id
        LEFT OUTER JOIN (
        SELECT
        R.principal_id AS role_principal_id,
        R.name AS role_name,
        RM.name AS role_member_name
        FROM sys.database_principals R
        JOIN sys.database_role_members DRM ON R.principal_id = DRM.role_principal_id
        JOIN sys.database_principals RM ON DRM.member_principal_id = RM.principal_id
        WHERE R.type = 'R'
        ) DBRM ON DP.principal_id = DBRM.role_principal_id
        WHERE PERM.permission_name IN ('CONTROL','ALTER ANY DATABASE AUDIT')
        ORDER BY
        permission_name,
        principal_name,
        role_member_name
    " | Sort-Object -Unique permission_name, principal_name, role_member_name
    if ($res) {
        $FindingDetails += "DBA, Confirm that an approved server documentation documents the following accounts as authorized to administer audits:`n$($res | Format-Table | Out-String)"
    }

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check query."
    }
    else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213906 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213906
        STIG ID    : SQL6-D0-001100
        Rule ID    : SV-213906r810829_rule
        CCI ID     : CCI-001499
        Rule Name  : SRG-APP-000133-DB-000179
        Rule Title : SQL Server must limit privileges to change software modules, to include stored procedures, functions, and triggers.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as instance
            , db_name() as databasename
            , P.type_desc AS principal_type
            , P.name AS principal_name
            , O.type_desc
            , CASE class
                WHEN 0 THEN DB_NAME()
                WHEN 1 THEN OBJECT_SCHEMA_NAME(major_id) + '.' + OBJECT_NAME(major_id)
                WHEN 3 THEN SCHEMA_NAME(major_id)
                ELSE class_desc + '(' + CAST(major_id AS nvarchar) + ')'
            END AS securable_name, DP.state_desc, DP.permission_name
        FROM sys.database_permissions DP
            JOIN sys.database_principals P ON DP.grantee_principal_id = P.principal_id
            LEFT OUTER JOIN sys.all_objects O ON O.object_id = DP.major_id
                AND O.type IN ('TR','TA','P','X','RF','PC','IF','FN','TF','U')
        WHERE DP.type IN ('AL','ALTG') AND DP.class IN (0, 1, 53)
    "
    if ($res) {
        $FindingDetails += "DBA, ensure the following accounts are authorized in the server documentation to change procedures, functions and triggers:`n$($res | Format-Table -AutoSize| Out-String)"
    }

    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as instance
            , db_name() as databasename
            , R.name AS role_name
            , M.type_desc AS principal_type
            , M.name AS principal_name
        FROM sys.database_principals R
            JOIN sys.database_role_members DRM ON R.principal_id = DRM.role_principal_id
            JOIN sys.database_principals M ON DRM.member_principal_id = M.principal_id
        WHERE R.name IN ('db_ddladmin','db_owner')
            AND M.name != 'dbo'
    "
    if ($res) {
        if ($FindingDetails -eq "") {
            #If the second query is the only query to return results, add the message to the DBA.
            $FindingDetails += "DBA, ensure the following accounts are authorized in the server documentation to change procedures, functions and triggers:`n"
        }
        $FindingDetails += $($res | Format-Table -AutoSize | Out-String)
    } # if ($res)

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check queries."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213907 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213907
        STIG ID    : SQL6-D0-001200
        Rule ID    : SV-213907r508025_rule
        CCI ID     : CCI-001499
        Rule Name  : SRG-APP-000133-DB-000179
        Rule Title : SQL Server must limit privileges to change software modules, to include stored procedures, functions, and triggers, and links to software external to SQL Server.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        with approvedschemas as (
        select 'db_accessadmin' as schema_name , 'db_accessadmin' as owning_principal
        union all select 'db_backupoperator'   , 'db_backupoperator'
        union all select 'db_datareader'       , 'db_datareader'
        union all select 'db_datawriter'       , 'db_datawriter'
        union all select 'db_ddladmin'         , 'db_ddladmin'
        union all select 'db_denydatareader'   , 'db_denydatareader'
        union all select 'db_denydatawriter'   , 'db_denydatawriter'
        union all select 'db_owner'            , 'db_owner'
        union all select 'db_securityadmin'    , 'db_securityadmin'
        union all select 'guest'               , 'guest'
        union all select 'INFORMATION_SCHEMA'  , 'INFORMATION_SCHEMA'
        union all select 'sys'                 , 'sys'
        union all select 'TargetServersRole'   , 'TargetServersRole'
        union all select 'SQLAgentUserRole'    , 'SQLAgentUserRole'
        union all select 'SQLAgentReaderRole'  , 'SQLAgentReaderRole'
        union all select 'SQLAgentOperatorRole', 'SQLAgentOperatorRole'
        union all select 'DatabaseMailUserRole', 'DatabaseMailUserRole'
        union all select 'db_ssisadmin'        , 'db_ssisadmin'
        union all select 'db_ssisltduser'      , 'db_ssisltduser'
        union all select 'db_ssisoperator'     , 'db_ssisoperator'
        )
        select @@servername as instance, db_name() as databasename
            , S.name AS schema_name
            , P.name AS owning_principal
        FROM sys.schemas S
        JOIN sys.database_principals P ON S.principal_id = P.principal_id
        where p.name != 'dbo'
        except
        select @@servername as instance, db_name() as databasename, schema_name, owning_principal
        from approvedschemas
    "
    if ($res) {
    # Per #304 return NR in case server documentation supports the settings
    # $Status = 'Open'
        $FindingDetails += "DBA, ensure the following principals are authorized in the server documentation to own schemas:`n$($res | Format-Table -AutoSize| Out-String)"
    }
    else {
        
        $Status = "NotAFinding"
        $FindingDetails = "No principals other than the standard MSSQL principals own database schemas."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213908 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213908
        STIG ID    : SQL6-D0-001300
        Rule ID    : SV-213908r508025_rule
        CCI ID     : CCI-001499
        Rule Name  : SRG-APP-000133-DB-000200
        Rule Title : Database objects (including but not limited to tables, indexes, storage, stored procedures, functions, triggers, links to software external to SQL Server, etc.) must be owned by database/DBMS principals authorized for ownership.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    # Check for accounts with the db_owner role...
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        ;with objects_cte as
        (SELECT o.name, o.type_desc,
        CASE
        WHEN o.principal_id is null then s.principal_id
        ELSE o.principal_id
        END as principal_id
        FROM sys.objects o
        INNER JOIN sys.schemas s
        ON o.schema_id = s.schema_id
        WHERE o.is_ms_shipped = 0
        )
        SELECT cte.name, cte.type_desc, dp.name as ObjectOwner
        FROM objects_cte cte
        INNER JOIN sys.database_principals dp
        ON cte.principal_id = dp.principal_id
        where dp.name != 'dbo'
        ORDER BY dp.name, cte.name
    " | Where-Object ObjectOwner -NE 'dbo'
    if ($res) {
        $FindingDetails += "DBA, Confirm that an approved server documentation documents the following accounts as authorized to own database objects:`n$($res | Format-Table | Out-String)"
    }

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check query."
    }
    else {
        $Status = "Open"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213909 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213909
        STIG ID    : SQL6-D0-001400
        Rule ID    : SV-213909r508025_rule
        CCI ID     : CCI-001499
        Rule Name  : SRG-APP-000133-DB-000362
        Rule Title : The role(s)/group(s) used to modify database structure (including but not necessarily limited to tables, indexes, storage, etc.) and logic modules (stored procedures, functions, triggers, links to software external to SQL Server, etc.) must be restricted to authorized users.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
    SELECT P.type_desc AS principal_type, P.name AS principal_name, O.type_desc,
    CASE class
    WHEN 0 THEN DB_NAME()
    WHEN 1 THEN OBJECT_SCHEMA_NAME(major_id) + '.' + OBJECT_NAME(major_id)
    WHEN 3 THEN SCHEMA_NAME(major_id)
    ELSE class_desc + '(' + CAST(major_id AS nvarchar) + ')'
    END AS securable_name, DP.state_desc, DP.permission_name
    FROM sys.database_permissions DP
    JOIN sys.database_principals P ON DP.grantee_principal_id = P.principal_id
    LEFT OUTER JOIN sys.all_objects O ON O.object_id = DP.major_id AND O.type IN ('TR','TA','P','X','RF','PC','IF','FN','TF','U')
    WHERE DP.type IN ('AL','ALTG') AND DP.class IN (0, 1, 53)
    "
    if ($res) {
        # Per #304 return NR in case server documentation supports the settings
        # $Status = 'Open'
        $FindingDetails += "DBA, ensure the following accounts are authorized in the server documentation to modify objects:`n$($res | Format-Table -AutoSize| Out-String)"
    }

    $res = Get-isql -ServerInstance $Instance -Database $Database "
    SELECT R.name AS role_name, M.type_desc AS principal_type, M.name AS principal_name
    FROM sys.database_principals R
    JOIN sys.database_role_members DRM ON R.principal_id = DRM.role_principal_id
    JOIN sys.database_principals M ON DRM.member_principal_id = M.principal_id
    WHERE R.name IN ('db_ddladmin','db_owner')
    AND M.name != 'dbo'
    "
    if ($res) {
        if ($FindingDetails -eq "") {
            # Per #304 return NR in case server documentation supports the settings
            # $Status = 'Open'
            $FindingDetails += "DBA, ensure the following accounts are authorized in the server documentation to modify objects:`n"
        }
        $FindingDetails += $($res | Format-Table -AutoSize | Out-String)
    } # if ($res)

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check queries."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213910 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213910
        STIG ID    : SQL6-D0-001500
        Rule ID    : SV-213910r508025_rule
        CCI ID     : CCI-001665
        Rule Name  : SRG-APP-000226-DB-000147
        Rule Title : In the event of a system failure, hardware loss or disk failure, SQL Server must be able to restore necessary databases with least disruption to mission processes.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        USE [master]
        GO
        SELECT name, recovery_model_desc
        FROM sys.databases
        ORDER BY name
    "
    $FindingDetails += "DBA, Using the system documentation, confirm, the following recovery models." 
    if ($res) {        
        $FindingDetails += "If the recovery model description does not match the documented recovery model, this is a finding.:`n$($res | Format-Table -AutoSize| Out-String)"
    } else {
        $FindingDetails += "No results were returned by the recovery model check query."
    }

    $res = Get-isql -ServerInstance $Instance -Database $Database "
        USE [msdb]
        GO
        SELECT database_name, 
        CASE type
        WHEN 'D' THEN 'Full'
        WHEN 'I' THEN 'Differential'
        WHEN 'L' THEN 'Log'
        ELSE type
        END AS backup_type,
        is_copy_only,backup_start_date, backup_finish_date
        FROM dbo.backupset
        WHERE backup_start_date >= dateadd(day, - 30, getdate()) 
        ORDER BY database_name, backup_start_date DESC
    "
    $FindingDetails += "DBA, Review the jobs set up to implement the backup plan. If they are absent, this is a finding.`n" 
    if ($res) {        
        $FindingDetails += "Jobs set up to implement the backup plan:`n$($res | Format-Table -AutoSize| Out-String)"
    } else {
        $Status = 'Open'
        $FindingDetails += "No results were returned by the backup plan check query."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213911 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213911
        STIG ID    : SQL6-D0-001600
        Rule ID    : SV-213911r508025_rule
        CCI ID     : CCI-001199
        Rule Name  : SRG-APP-000231-DB-000154
        Rule Title : The Database Master Key encryption password must meet DOD password complexity requirements.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as Instance
            , db_name() as DatabaseName
            , COUNT(name)  keycount
    FROM sys.symmetric_keys s, sys.key_encryptions k
    WHERE s.name = '##MS_DatabaseMasterKey##'
    AND s.symmetric_key_id = k.key_id
    AND k.crypt_type in ('ESKP', 'ESP2', 'ESP3')"
    if ($res) {
        $res2 = $res | Where-Object keycount -GT 0
        if ($res2) {
            $FindingDetails = "Review procedures and evidence of password requirements used to encrypt the following Database Master Keys:`n$($res2 | Format-Table -AutoSize| Out-String)"
            $Status = 'Open'
        }
    }
    if ($FindingDetails -eq "") {
        $Status = "Not_Applicable"
        $FindingDetails = "No database master keys exist."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213912 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213912
        STIG ID    : SQL6-D0-001700
        Rule ID    : SV-213912r508025_rule
        CCI ID     : CCI-001199
        Rule Name  : SRG-APP-000231-DB-000154
        Rule Title : The Database Master Key must be encrypted by the Service Master Key, where a Database Master Key is required and another encryption method has not been specified.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
    SELECT name
    FROM [master].sys.databases
    WHERE is_master_key_encrypted_by_server = 1
    AND owner_sid <> 1
    AND state = 0;
    "
    if ($res) {
        $Status = 'Open'
        $FindingDetails += "DBA, ensure the server documentation has approved the encryption of these database master keys using the service master keys:`n$($res | Format-Table -AutoSize| Out-String)"
    }

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check query."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213914 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213914
        STIG ID    : SQL6-D0-001900
        Rule ID    : SV-213914r822449_rule
        CCI ID     : CCI-001084
        Rule Name  : SRG-APP-000233-DB-000124
        Rule Title : SQL Server must isolate security functions from non-security functions.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    #master, msdb, model, tempdb
    $DefaultDatabases = "master, msdb, model, tempdb"
    If ($DefaultDatabases.IndexOf($Database) -ne -1) {
        $Status = "Not_Applicable"
        $FindingDetails += "This is the '$Database' database so this requirement is NA."
    } else {
        $res = Get-isql -ServerInstance $Instance -Database $Database "
        USE [master]
        GO
        SELECT Name 
        FROM sys.databases 
        WHERE database_id > 4 
        ORDER BY 1;
        "

        if ($res) {
            $FindingDetails += "DBA, Review the database structure to determine where security related functionality is stored.`n If security-related database objects or code are not kept separate, this is a finding:`n$($res | Format-Table -AutoSize| Out-String)"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213918 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213918
        STIG ID    : SQL6-D0-002500
        Rule ID    : SV-213918r855953_rule
        CCI ID     : CCI-002262
        Rule Name  : SRG-APP-000311-DB-000308
        Rule Title : SQL Server must associate organization-defined types of security labels having organization-defined security label values with information in storage.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    #master, msdb, model, tempdb
    $DefaultDatabases = "master, msdb, model, tempdb"
    If ($DefaultDatabases.IndexOf($Database) -ne -1) {
        $Status = "NotAFinding"
        $FindingDetails += "This is the '$Database' database so per STIG Support modifying the default databases not required nor recommended.  For the default databases this check is an automatic 'Not A Finding'"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213919 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213919
        STIG ID    : SQL6-D0-002600
        Rule ID    : SV-213919r855954_rule
        CCI ID     : CCI-002263
        Rule Name  : SRG-APP-000313-DB-000309
        Rule Title : SQL Server must associate organization-defined types of security labels having organization-defined security label values with information in process.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    #master, msdb, model, tempdb
    $DefaultDatabases = "master, msdb, model, tempdb"
    If ($DefaultDatabases.IndexOf($Database) -ne -1) {
        $Status = "NotAFinding"
        $FindingDetails += "This is the '$Database' database so per STIG Support modifying the default databases not required nor recommended.  For the default databases this check is an automatic 'Not A Finding'"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213920 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213920
        STIG ID    : SQL6-D0-002700
        Rule ID    : SV-213920r855955_rule
        CCI ID     : CCI-002264
        Rule Name  : SRG-APP-000314-DB-000310
        Rule Title : SQL Server must associate organization-defined types of security labels having organization-defined security label values with information in transmission.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    #master, msdb, model, tempdb
    $DefaultDatabases = "master, msdb, model, tempdb"
    If ($DefaultDatabases.IndexOf($Database) -ne -1) {
        $Status = "NotAFinding"
        $FindingDetails += "This is the '$Database' database so per STIG Support modifying the default databases not required nor recommended.  For the default databases this check is an automatic 'Not A Finding'"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213921 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213921
        STIG ID    : SQL6-D0-002800
        Rule ID    : SV-213921r855956_rule
        CCI ID     : CCI-002165
        Rule Name  : SRG-APP-000328-DB-000301
        Rule Title : SQL Server must enforce discretionary access control policies, as defined by the data owner, over defined subjects and objects.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as instance
            , db_name() as databasename
            , name AS schema_name
            , USER_NAME(principal_id) AS schema_owner
        FROM sys.schemas
        WHERE schema_id != principal_id
        AND principal_id != 1
    "
    if ($res) {
        $Status = 'Open'
        $FindingDetails += "DBA, ensure the following accounts are authorized in the server documentation to own schemas:`n$($res | Format-Table -AutoSize| Out-String)"
    }

    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as instance
            , db_name() as databasename
            , object_id
            , name AS securable
            , USER_NAME(principal_id) AS object_owner
            , type_desc
        FROM sys.objects
        WHERE is_ms_shipped = 0 AND principal_id IS NOT NULL
        ORDER BY type_desc, securable, object_owner
    "
    if ($res) {
        if ($FindingDetails -eq "") {
            $Status = 'Open'
            $FindingDetails += "DBA, ensure the following accounts are authorized in the server documentation to own objects:`n"
        }
        $FindingDetails += $($res | Format-Table -AutoSize | Out-String)
    } # if ($res)

    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as instance
            , db_name() as databasename
            , U.type_desc
            , U.name AS grantee
            , DP.class_desc AS securable_type
            , CASE DP.class
                WHEN 0 THEN DB_NAME()
                WHEN 1 THEN OBJECT_NAME(DP.major_id)
                WHEN 3 THEN SCHEMA_NAME(DP.major_id)
                ELSE CAST(DP.major_id AS nvarchar)
            END AS securable
            , permission_name
            , state_desc
        FROM sys.database_permissions DP
        JOIN sys.database_principals U ON DP.grantee_principal_id = U.principal_id
        WHERE DP.state = 'W'
        ORDER BY grantee, securable_type, securable
    "
    if ($res) {
        if ($FindingDetails -eq "") {
            $Status = 'Open'
            $FindingDetails += "DBA, ensure the following accounts are authorized in the server documentation to assig additional permissions:`n"
        }
        $FindingDetails += $($res | Format-Table -AutoSize | Out-String)
    } # if ($res)

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check queries."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213922 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213922
        STIG ID    : SQL6-D0-002900
        Rule ID    : SV-213922r855957_rule
        CCI ID     : CCI-002233
        Rule Name  : SRG-APP-000342-DB-000302
        Rule Title : Execution of stored procedures and functions that utilize execute as must be restricted to necessary cases only.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as instance
            , db_name() as databasename
            , S.name AS schema_name
            , O.name AS module_name
            , USER_NAME(
                CASE M.execute_as_principal_id
                WHEN -2 THEN COALESCE(O.principal_id, S.principal_id)
                ELSE M.execute_as_principal_id
                END
            ) AS execute_as
        FROM sys.sql_modules M
        JOIN sys.objects O ON M.object_id = O.object_id
        JOIN sys.schemas S ON O.schema_id = S.schema_id
        WHERE execute_as_principal_id IS NOT NULL
        and o.name not in (
                'fn_sysdac_get_username',
                'fn_sysutility_ucp_get_instance_is_mi',
                'sp_send_dbmail',
                'sp_SendMailMessage',
                'sp_syscollector_create_collection_set',
                'sp_syscollector_delete_collection_set',
                'sp_syscollector_disable_collector',
                'sp_syscollector_enable_collector',
                'sp_syscollector_get_collection_set_execution_status',
                'sp_syscollector_run_collection_set',
                'sp_syscollector_start_collection_set',
                'sp_syscollector_update_collection_set',
                'sp_syscollector_upload_collection_set',
                'sp_syscollector_verify_collector_state',
                'sp_syspolicy_add_policy',
                'sp_syspolicy_add_policy_category_subscription',
                'sp_syspolicy_delete_policy',
                'sp_syspolicy_delete_policy_category_subscription',
                'sp_syspolicy_update_policy',
                'sp_sysutility_mi_add_ucp_registration',
                'sp_sysutility_mi_disable_collection',
                'sp_sysutility_mi_enroll',
                'sp_sysutility_mi_initialize_collection',
                'sp_sysutility_mi_remove',
                'sp_sysutility_mi_remove_ucp_registration',
                'sp_sysutility_mi_upload',
                'sp_sysutility_mi_validate_enrollment_preconditions',
                'sp_sysutility_ucp_add_mi',
                'sp_sysutility_ucp_add_policy',
                'sp_sysutility_ucp_calculate_aggregated_dac_health',
                'sp_sysutility_ucp_calculate_aggregated_mi_health',
                'sp_sysutility_ucp_calculate_computer_health',
                'sp_sysutility_ucp_calculate_dac_file_space_health',
                'sp_sysutility_ucp_calculate_dac_health',
                'sp_sysutility_ucp_calculate_filegroups_with_policy_violations',
                'sp_sysutility_ucp_calculate_health',
                'sp_sysutility_ucp_calculate_mi_file_space_health',
                'sp_sysutility_ucp_calculate_mi_health',
                'sp_sysutility_ucp_configure_policies',
                'sp_sysutility_ucp_create',
                'sp_sysutility_ucp_delete_policy',
                'sp_sysutility_ucp_delete_policy_history',
                'sp_sysutility_ucp_get_policy_violations',
                'sp_sysutility_ucp_initialize',
                'sp_sysutility_ucp_initialize_mdw',
                'sp_sysutility_ucp_remove_mi',
                'sp_sysutility_ucp_update_policy',
                'sp_sysutility_ucp_update_utility_configuration',
                'sp_sysutility_ucp_validate_prerequisites',
                'sp_validate_user',
                'syscollector_collection_set_is_running_update_trigger',
                'sysmail_help_status_sp'
            )
        ORDER BY schema_name, module_name
    "
    if ($res) {
        $Status = 'Open'
        $FindingDetails += "DBA, ensure the following SQL modules are authorized in the server documentation to utilize impersonation:`n$($res | Format-Table -AutoSize| Out-String)"
    }

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check queries."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213923 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213923
        STIG ID    : SQL6-D0-003000
        Rule ID    : SV-213923r855958_rule
        CCI ID     : CCI-001812
        Rule Name  : SRG-APP-000378-DB-000365
        Rule Title : SQL Server must prohibit user installation of logic modules (stored procedures, functions, triggers, views, etc.) without explicit privileged status.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as instance
            , db_name() as databasename
            , P.type_desc AS principal_type
            , P.name AS principal_name
            , O.type_desc
            , CASE class
                WHEN 0 THEN DB_NAME()
                WHEN 1 THEN OBJECT_SCHEMA_NAME(major_id) + '.' + OBJECT_NAME(major_id)
                WHEN 3 THEN SCHEMA_NAME(major_id)
                ELSE class_desc + '(' + CAST(major_id AS nvarchar) + ')'
            END AS securable_name, DP.state_desc
            , DP.permission_name
        FROM sys.database_permissions DP
        JOIN sys.database_principals P ON DP.grantee_principal_id = P.principal_id
        LEFT OUTER JOIN sys.all_objects O ON O.object_id = DP.major_id AND O.type IN ('TR','TA','P','X','RF','PC','IF','FN','TF','U')
        WHERE DP.type IN ('AL','ALTG') AND DP.class IN (0, 1, 53)
    "
    if ($res) {
        $Status = 'Open'
        $FindingDetails += "DBA, ensure the following principals are authorized in the server documentation to modify the specified object or type:`n$($res | Format-Table -AutoSize| Out-String)"
    }

    $res = Get-isql -ServerInstance $Instance -Database $Database "
        SELECT @@servername as instance
            , db_name() as databasename
            , R.name AS role_name
            , M.type_desc AS principal_type
            , M.name AS principal_name
        FROM sys.database_principals R
        JOIN sys.database_role_members DRM ON R.principal_id = DRM.role_principal_id
        JOIN sys.database_principals M ON DRM.member_principal_id = M.principal_id
        WHERE R.name IN ('db_ddladmin','db_owner')
        AND M.name != 'dbo'
    "
    if ($res) {
        if ($FindingDetails -eq "") {
            $Status = 'Open'
            $FindingDetails += "DBA, ensure the following user/role memberships are authorized in the server documentation:`n"
        }
        $FindingDetails += $($res | Format-Table -AutoSize | Out-String)
    } # if ($res)

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check queries."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213924 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213924
        STIG ID    : SQL6-D0-003100
        Rule ID    : SV-213924r855959_rule
        CCI ID     : CCI-001813
        Rule Name  : SRG-APP-000380-DB-000360
        Rule Title : SQL Server must enforce access restrictions associated with changes to the configuration of the database(s).
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
    SELECT D.name AS database_name, SUSER_SNAME(D.owner_sid) AS owner_name,
    FRM.is_fixed_role_member
   FROM sys.databases D
   OUTER APPLY (
    SELECT MAX(fixed_role_member) AS is_fixed_role_member
    FROM (
    SELECT IS_SRVROLEMEMBER(R.name, SUSER_SNAME(D.owner_sid)) AS fixed_role_member
    FROM sys.server_principals R
    WHERE is_fixed_role = 1
    ) A
   ) FRM
   WHERE D.database_id > 4
    AND (FRM.is_fixed_role_member = 1
    OR FRM.is_fixed_role_member IS NULL)
   ORDER BY database_name
    "
    if ($res) {
        $Status = 'Open'
        $FindingDetails += "DBA, Remove unauthorized users from roles`n$($res | Format-Table -AutoSize | Out-String)"
    }

    if ($FindingDetails -eq "") {
        $Status = "NotAFinding"
        $FindingDetails = "No results were returned by the check queries."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V213926 {
    <#
    .DESCRIPTION
        Vuln ID    : V-213926
        STIG ID    : SQL6-D0-003300
        Rule ID    : SV-213926r855960_rule
        CCI ID     : CCI-002475
        Rule Name  : SRG-APP-000428-DB-000386
        Rule Title : SQL Server must implement cryptographic mechanisms to prevent unauthorized modification of organization-defined information at rest (to include, at a minimum, PII and classified information) on organization-defined information system components.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-isql -ServerInstance $Instance -Database $Database "
    SELECT
    DB_NAME(database_id) AS [Database Name], CASE encryption_state WHEN 0 THEN 'No database encryption key present, no encryption' 
    WHEN 1 THEN 'Unencrypted' 
    WHEN 2 THEN 'Encryption in progress' 
    WHEN 3 THEN 'Encrypted' 
    WHEN 4 THEN 'Key change in progress' 
    WHEN 5 THEN 'Decryption in progress' 
    WHEN 6 THEN 'Protection change in progress' 
    END AS [Encryption State]
    FROM sys.dm_database_encryption_keys
    "
    if ($res) {
        $FindingDetails += "DBA, review server documentation for each user database for which encryption is called for and it is marked Unencrypted, this is a finding`n$($res | Format-Table -AutoSize | Out-String)"
    }

    if ($FindingDetails -eq "") {
        $FindingDetails = "No results were returned by the check query."
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V251040 {
    <#
    .DESCRIPTION
        Vuln ID    : V-251040
        STIG ID    : SQL6-D0-003200
        Rule ID    : SV-251040r863346_rule
        CCI ID     : CCI-002450
        Rule Name  : SRG-APP-000416-DB-000380
        Rule Title : SQL Server must use NSA-approved cryptography to protect classified information in accordance with the data owners requirements.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,
        [Parameter(Mandatory = $true)]
        [String]$ScanType,
        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,
        [Parameter(Mandatory = $true)]
        [String]$Instance,
        [Parameter(Mandatory = $true)]
        [String]$Database,
        [Parameter(Mandatory = $false)]
        [String]$Username,
        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $res = Get-ItemPropertyValue "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy" -Name Enabled
    
    if (!$res) {
        $Status = "Open"
        $FindingDetails = "FIPS-compliant algorithms for encryption, hashing, and signing setting (HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy) was not found."
    }
    else {
        if ($res -eq "0") {
            $Status = "Open"
            $FindingDetails = "FIPS-compliant algorithms for encryption, hashing, and signing is not enabled:`n$($res | Format-Table -AutoSize| Out-String)"
        }
        else {
            $res2 = Get-ISQL -ServerInstance $h "SELECT DISTINCT name, algorithm_desc
                FROM sys.symmetric_keys
                WHERE key_algorithm NOT IN ('D3','A3')
                ORDER BY name"                
            if ($res2) {
                $Status = "Open"
                $FindingDetails = "FIPS-compliant algorithms for encryption, uncertified NIST FIPS algorithm type:`n$($res2 | Format-Table -AutoSize| Out-String)"
            } else {
                $Status = "NotAFinding"
                $FindingDetails = "FIPS-compliant algorithms for encryption, hashing, and signing is enabled:`n$($res | Format-Table -AutoSize| Out-String)"
            }
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

# SIG # Begin signature block
# MIIL1AYJKoZIhvcNAQcCoIILxTCCC8ECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUMXbnGOJfkCCYSlpq+d/w41MW
# qLmgggk7MIIEejCCA2KgAwIBAgIEAwIE1zANBgkqhkiG9w0BAQsFADBaMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MB4XDTIwMDcxNTAw
# MDAwMFoXDTI1MDQwMjEzMzgzMlowaTELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxDDAKBgNV
# BAsTA1VTTjEWMBQGA1UEAxMNQ1MuTlNXQ0NELjAwMTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANv2fdTmx2dNPQ47F8kmvU+g20/sFoF+DS3k2GcMduuI
# XxYFJyMMPAvTJuobeJlX6P6sr5jAKhXXsoV4lT2boWw583Snl6cuSfqMbVowIJ1s
# CffN7N0VXsLVdOt1u5GCKs4/jXH7MeEOE0oJsgEjjE1IZc5tEqj++s1N1EUY+jf/
# zc8QHDjy5X88XBTzKVhwvczZVbRahrcmYv0k4we3ndwTl5nXYizSwi96CZuqzrIn
# WbLSsRLNyNZZVo7J5bZ+30dv/hZvq6FqxfAeM3pEDrvbfFkWXzaISqF1bVbsMlAC
# UBf/JFbSGtmMsU1ABfXKPalTWYJKP58dICHcUocZhL0CAwEAAaOCATcwggEzMB8G
# A1UdIwQYMBaAFHUJphUTroc8+nOUAPLw9Xm5snIUMEEGA1UdHwQ6MDgwNqA0oDKG
# MGh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNTlfTkNPREVTSUdOLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyowHQYDVR0O
# BBYEFFbrF3OpzfdsZkN1zTfv++oaLCRRMGUGCCsGAQUFBwEBBFkwVzAzBggrBgEF
# BQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNTkuY2VyMCAG
# CCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAWBgorBgEE
# AYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAQknaIAXDnyqshmyh
# uOZS4nBtSydnZrdB8Je0JCq2TTRA4dkNvrswe0kZgA7UjlY1X/9PtQeIwaMrcvdF
# i+dqzD1bbW/LX5tH/1oMOp4s+VkGfl4xUUxUGjO6QTVOeLyN2x+DBQU11DhKEq9B
# RCxUGgclFn1iqxi5xKmLaQ3XuRWRGCkb+rXejWR+5uSTognxCuoLp95bqu3JL8ec
# yF46+VSoafktAGot2Uf3qmwWdMHFBdwzmJalbC4j09I1qJqcJH0p8Wt34zRw/hSr
# 3f+xDEDP8GNL2ciDm7aN0GKy67ugjgMmPXAv7A4/keCuN/dsNS1naNyqzc5AhTAF
# +o/21jCCBLkwggOhoAMCAQICAgMFMA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTE5MDQwMjEzMzgz
# MloXDTI1MDQwMjEzMzgzMlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4g
# R292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMT
# DERPRCBJRCBDQS01OTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMwX
# hJ8twQpXrRFNNVc/JEcvHA9jlr27cDE8rpxWkobvpCJOoOVUbJ724Stx6OtTAZpR
# iXNaS0jjRgYaW6cq9pdnjjQM5ovHPPde1ewaZyWb2I+uqhkZmOBV1+lGUOhnQCyi
# nnSSqzEH1PC5nASfyxnCdBeOt+UKHBrPVKBUuYS4Fcn5Q0wv+sfBD24vyV5Ojeoq
# HeSSAMTaeqlv+WQb4YrjKNfaGF+S7lMvQelu3ANHEcoL2HMCimCvnCHQaMQI9+Ms
# NhySPEULePdEDxgpWYc9FmBbjUp1CYEx7HYdlTRJ9gBHts2ITxTZQrt4Epjkqeb8
# aWVmzCEPHE7+KUVhuO8CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyKlKJ3sYBy
# HYF6Fqry3M5m7kXAMB0GA1UdDgQWBBR1CaYVE66HPPpzlADy8PV5ubJyFDAOBgNV
# HQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsn
# MAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgB
# ZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQE
# BTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3Js
# L0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0
# cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3YzAgBggr
# BgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQELBQADggEB
# ADkFG9IOpz71qHNXCeYJIcUshgN20CrvB5ym4Pr7zKTBRMKNqd9EXWBxrwP9xhra
# 5YcQagHDqnmBeU3F2ePhWvQmyhPwIJaArk4xGLdv9Imkr3cO8vVapO48k/R9ZRSA
# EBxzd0xMDdZ6+xxFlZJIONRlxcVNNVB30e74Kk08/t82S9ogqgA1Q7KZ2tFuaRes
# jJWuoJ+LtE5lrtknqgaXLb3XH0hV5M0AWRk9Wg/1thb9NCsKEIAdpdnolZOephIz
# fzHiOSqeJ+e5qURLB7rT+F5y0NNWTdqoJ/vOOCUa8z0NKWsz2IkpeD3iNhVCLRKw
# Ojm/wzxdG2tst5OHRZFEwKcxggIDMIIB/wIBATBiMFoxCzAJBgNVBAYTAlVTMRgw
# FgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMD
# UEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNTkCBAMCBNcwCQYFKw4DAhoFAKB4MBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYE
# FBTXYXJTVZjVeWwOi+uESCzpIeZhMA0GCSqGSIb3DQEBAQUABIIBAI5/2z0Utee6
# NwZ+NBipGJUZeY1s3DkmQ+Q+ChMjdEGQkbKPYfIN6HWU7F/QrxSun7yLDe01ut/g
# k7EnmiPAaDXIr6TVdnxEObu1RBg6N/tQc339sXZKhyX/mfCnHYXD7CYEquHJIzzm
# CX6EO4IQH1h5cqguP5wh5Z7odQgcR5HJU4JAR9Xuklci/xtwUgVe6IlKRFtej1WM
# Lxm6qHr2m8NCtrJACFOwAlhp5aTm67y/aYltqiIW3MUiL0nv4hgKVxVZS/35JS/9
# MQRDSiZxvNbH1zpPysaitAAZJI70rlDeLIACixt92pWm+v9fJGsMZVMHN4/e8iPQ
# JCj2FgWRZhU=
# SIG # End signature block
