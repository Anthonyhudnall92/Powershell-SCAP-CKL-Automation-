##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Active Directory Forest
# Version:  V2R8
# Class:    UNCLASSIFIED
# Updated:  8/9/2022
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Get-V8555 {
    <#
    .DESCRIPTION
        Vuln ID    : V-8555
        STIG ID    : AD.0230
        Rule ID    : SV-9052r2_rule
        CCI ID     : CCI-000366
        Rule Name  : DS10.0230 dsHeuristics Option
        Rule Title : Anonymous Access to AD forest data above the rootDSE level must be disabled.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    ForEach ($dc in ((Get-CimInstance Win32_ComputerSystem).Domain).ToString().Split(".")) {
        $Domain += ",dc=$($dc)"
    }
    $LdapObject = ("CN=Directory Service,CN=Windows NT,CN=Services,CN=Configuration" + $Domain)
    $ReturnedValue = (Get-ADObject -Identity $LdapObject -Properties dsHeuristics).dsHeuristics
    $SettingName = "Anonymous access to AD Forest"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.


    If ($ReturnedValue.Length -eq 0) {
        $Status = "NotAFinding"
        $FindingDetails += "'dsHeuristics' is not configured." | Out-String
    }
    Else {
        If ($ReturnedValue.Length -ge 7 -and $ReturnedValue[6] -eq "2") {
            $Status = "Open"
            $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "dsHeuristics:`t'$ReturnedValue'" | Out-String
        }
        Else {
            $Status = "NotAFinding"
            $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "dsHeuristics:`t'$ReturnedValue'" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V8557 {
    <#
    .DESCRIPTION
        Vuln ID    : V-8557
        STIG ID    : AD.0295
        Rule ID    : SV-9054r3_rule
        CCI ID     : CCI-001891
        Rule Name  : Time Synchronization-Authoritative Source
        Rule Title : The Windows Time Service on the forest root PDC Emulator must be configured to acquire its time from an external time source.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainRole = (Get-CimInstance Win32_ComputerSystem).DomainRole
    If ($DomainRole -ne "5") {
        $Status = "Not_Applicable"
        $FindingDetails += "This system is not the PDC Emulator so this requirement is NA."
    }
    Else {
        $W32TM = w32tm /query /configuration
        $Compliant = $true
        $ClientType = ($W32TM -Match "(?:Type: )(.*$)").Split(":")[1].Trim()
        If ($ClientType -notmatch "NTP") {
            # Finding
            $Compliant = $false
            $FindingDetails += "NTP Client Type is NOT Configured" | Out-String
            $FindingDetails += "Value: $($ClientType) [Expected: NTP]" | Out-String
            $FindingDetails += "" | Out-String
        }
        Else {
            # Configured Properly
            $FindingDetails += "NTP Client Type is Configured" | Out-String
            $FindingDetails += "Value:`t$($ClientType)" | Out-String
            $FindingDetails += "" | Out-String

            #This value only exists if Type is set to NTP
            $NTPServers = ($W32TM -Match "(?:NtpServer: )(.*$)").Split(":")[1].Replace('(Policy)', "").Trim()
            If ($NTPServers.Length -gt 0) {
                $FindingDetails += "" | Out-String
                $FindingDetails += "Configured NTP Servers" | Out-String
                $FindingDetails += "===========================" | Out-String
                ForEach ($Server in $NTPServers) {
                    $FindingDetails += "`t$($Server)" | Out-String
                }
            }
            else {
                $Compliant = $false
                $FindingDetails += "NTP Servers are NOT Configured" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "Value: (Not Found)" | Out-String
            }
        }

        If ($Compliant -eq $false) {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V15372 {
    <#
    .DESCRIPTION
        Vuln ID    : V-15372
        STIG ID    : DS00.3140_AD
        Rule ID    : SV-30999r4_rule
        CCI ID     : CCI-002235
        Rule Name  : Directory Schema Update Access
        Rule Title : Update access to the directory schema must be restricted to appropriate accounts.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $NonNormCount = 0
    $NonNormPerms = @()

    If (($PsVersionTable.PSVersion -join ".") -lt [Version]"6.0") {
        $SchemaPermissions = $(Get-Acl "AD:$((Get-ADRootDSE).schemaNamingContext)").Access | Sort-Object IdentityReference, ActiveDirectoryRights | Select-Object IdentityReference, ActiveDirectoryRights, ObjectType
    }
    Else {
        $PSCommand = 'PowerShell.exe -Command {$(Get-Acl "AD:$((Get-ADRootDSE).schemaNamingContext)").Access | Sort-Object IdentityReference, ActiveDirectoryRights | Select-Object IdentityReference, ActiveDirectoryRights, ObjectType}'
        $SchemaPermissions = Invoke-Expression $PSCommand
    }

    $FindingDetails += "`nSchema Permissions:" | Out-String
    ForEach ($SchemaPermission in $SchemaPermissions) {
        If (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\Authenticated Users") -and ($SchemaPermission.ActiveDirectoryRights -eq "GenericRead")) {
            $FindingDetails += "  Permissions are set to the default for: Authenticated Users - Read" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\SYSTEM") -and ($SchemaPermission.ActiveDirectoryRights -eq "GenericAll")) {
            $FindingDetails += "  Permissions are set to the default for: System - Full Control" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -like "*\Enterprise Read-only Domain Controllers") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Read-only Domain Controllers - Replicating Directory Changes" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -like "*\Enterprise Read-only Domain Controllers") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Read-only Domain Controllers - Replicating Directory Changes All" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -like "*\Enterprise Read-only Domain Controllers") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "89e95b76-444d-4c62-991a-0facbeda640c")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Read-only Domain Controllers - Replicating Directory Changes In Filtered Set" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -Like "*\Schema Admins") -and (($SchemaPermission.ActiveDirectoryRights -like "*CreateChild*") -or ($SchemaPermission.ActiveDirectoryRights -like "*Self*") -or ($SchemaPermission.ActiveDirectoryRights -like "*WriteProperty*") -or ($SchemaPermission.ActiveDirectoryRights -like "*GenericRead*") -or ($SchemaPermission.ActiveDirectoryRights -like "*WriteDacl*") -or ($SchemaPermission.ActiveDirectoryRights -like "*WriteOwner*"))) {
            $FindingDetails += "  Permissions are set to the default for: Schema Admins - Special (except Full, Delete, and Delete subtree)" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -like "*\Schema Admins") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "e12b56b6-0a95-11d1-adbb-00c04fd8d5cd")) {
            $FindingDetails += "  Permissions are set to the default for: Schema Admins - Change schema master" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ac-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Manage replication topology" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Replicating Directory Changes" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Replicating Directory Changes All" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "89e95b76-444d-4c62-991a-0facbeda640c")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Replicating Directory Changes In Filtered Set" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ab-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Replication Synchronization" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ac-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Manage replication topology" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Replicating Directory Changes" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Replicating Directory Changes All" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "89e95b76-444d-4c62-991a-0facbeda640c")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Replicating Directory Changes In Filtered Set" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ab-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Replication Synchronization" | Out-String
        }
        Else {
            ++$NonNormCount
            $NonNormPerms += $SchemaPermission | Select-Object IdentityReference, ActiveDirectoryRights, ObjectType
        }
    }

    If ($NonNormCount -ge 1) {
        $Status = "Open"
        $FindingDetails += "`nNon Standard Permissions in the Schema Permissions:" | Out-String
        $FindingDetails += "_______________________________________________________________________" | Out-String
        ForEach ($Object in $NonNormPerms) {
            $FindingDetails += "IdentityReference:`t`t$($Object.IdentityReference)" | Out-String
            $FindingDetails += "ActiveDirectoryRights:`t$($Object.ActiveDirectoryRights)" | Out-String
            $FindingDetails += "ObjectType:`t`t`t$($Object.ObjectType)" | Out-String
        }
    }
    Else {
        $Status = "NotAFinding"
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V72835 {
    <#
    .DESCRIPTION
        Vuln ID    : V-72835
        STIG ID    : AD.0017
        Rule ID    : SV-87487r1_rule
        CCI ID     : CCI-000366
        Rule Name  : AD.0017
        Rule Title : Membership to the Schema Admins group must be limited.
    #>

    Param (
        [Parameter(Mandatory = $False)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $True)]
        [String]$ScanType,

        [Parameter(Mandatory = $True)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $False)]
        [String]$Username,

        [Parameter(Mandatory = $False)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $GroupName = "Schema Admins"
    $Members = (Get-ADGroupMember $GroupName | Select-Object Name, SID, ObjectClass | Sort-Object Name) #to see members in schema admins
    If (($Members | Measure-Object).Count -le 0) {
        $Status = "NotAFinding"
        $FindingDetails += "$GroupName has no members."
    }
    Else {
        If (($Members | Measure-Object).Count -eq 1 -and $Members.Name -eq "BUILTIN\Administrators") {
            $Status = "NotAFinding"
        }
        $FindingStatus += "Members of the $($GroupName)"
        $FindingDetails += "=" * (12 + $GroupName.Length) | Out-String
        ForEach ($Object in $Members) {
            $FindingDetails += "Name:`t$($Object.Name)" | Out-String
            $FindingDetails += "SID:`t`t$($Object.SID)" | Out-String
            $FindingDetails += "Type:`t$($Object.ObjectClass)" | Out-String
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

# SIG # Begin signature block
# MIIL1AYJKoZIhvcNAQcCoIILxTCCC8ECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU/y+2KVvFo8+aQnwrbg5QMnc6
# ZNqgggk7MIIEejCCA2KgAwIBAgIEAwIE1zANBgkqhkiG9w0BAQsFADBaMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MB4XDTIwMDcxNTAw
# MDAwMFoXDTI1MDQwMjEzMzgzMlowaTELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxDDAKBgNV
# BAsTA1VTTjEWMBQGA1UEAxMNQ1MuTlNXQ0NELjAwMTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANv2fdTmx2dNPQ47F8kmvU+g20/sFoF+DS3k2GcMduuI
# XxYFJyMMPAvTJuobeJlX6P6sr5jAKhXXsoV4lT2boWw583Snl6cuSfqMbVowIJ1s
# CffN7N0VXsLVdOt1u5GCKs4/jXH7MeEOE0oJsgEjjE1IZc5tEqj++s1N1EUY+jf/
# zc8QHDjy5X88XBTzKVhwvczZVbRahrcmYv0k4we3ndwTl5nXYizSwi96CZuqzrIn
# WbLSsRLNyNZZVo7J5bZ+30dv/hZvq6FqxfAeM3pEDrvbfFkWXzaISqF1bVbsMlAC
# UBf/JFbSGtmMsU1ABfXKPalTWYJKP58dICHcUocZhL0CAwEAAaOCATcwggEzMB8G
# A1UdIwQYMBaAFHUJphUTroc8+nOUAPLw9Xm5snIUMEEGA1UdHwQ6MDgwNqA0oDKG
# MGh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNTlfTkNPREVTSUdOLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyowHQYDVR0O
# BBYEFFbrF3OpzfdsZkN1zTfv++oaLCRRMGUGCCsGAQUFBwEBBFkwVzAzBggrBgEF
# BQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNTkuY2VyMCAG
# CCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAWBgorBgEE
# AYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAQknaIAXDnyqshmyh
# uOZS4nBtSydnZrdB8Je0JCq2TTRA4dkNvrswe0kZgA7UjlY1X/9PtQeIwaMrcvdF
# i+dqzD1bbW/LX5tH/1oMOp4s+VkGfl4xUUxUGjO6QTVOeLyN2x+DBQU11DhKEq9B
# RCxUGgclFn1iqxi5xKmLaQ3XuRWRGCkb+rXejWR+5uSTognxCuoLp95bqu3JL8ec
# yF46+VSoafktAGot2Uf3qmwWdMHFBdwzmJalbC4j09I1qJqcJH0p8Wt34zRw/hSr
# 3f+xDEDP8GNL2ciDm7aN0GKy67ugjgMmPXAv7A4/keCuN/dsNS1naNyqzc5AhTAF
# +o/21jCCBLkwggOhoAMCAQICAgMFMA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTE5MDQwMjEzMzgz
# MloXDTI1MDQwMjEzMzgzMlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4g
# R292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMT
# DERPRCBJRCBDQS01OTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMwX
# hJ8twQpXrRFNNVc/JEcvHA9jlr27cDE8rpxWkobvpCJOoOVUbJ724Stx6OtTAZpR
# iXNaS0jjRgYaW6cq9pdnjjQM5ovHPPde1ewaZyWb2I+uqhkZmOBV1+lGUOhnQCyi
# nnSSqzEH1PC5nASfyxnCdBeOt+UKHBrPVKBUuYS4Fcn5Q0wv+sfBD24vyV5Ojeoq
# HeSSAMTaeqlv+WQb4YrjKNfaGF+S7lMvQelu3ANHEcoL2HMCimCvnCHQaMQI9+Ms
# NhySPEULePdEDxgpWYc9FmBbjUp1CYEx7HYdlTRJ9gBHts2ITxTZQrt4Epjkqeb8
# aWVmzCEPHE7+KUVhuO8CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyKlKJ3sYBy
# HYF6Fqry3M5m7kXAMB0GA1UdDgQWBBR1CaYVE66HPPpzlADy8PV5ubJyFDAOBgNV
# HQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsn
# MAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgB
# ZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQE
# BTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3Js
# L0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0
# cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3YzAgBggr
# BgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQELBQADggEB
# ADkFG9IOpz71qHNXCeYJIcUshgN20CrvB5ym4Pr7zKTBRMKNqd9EXWBxrwP9xhra
# 5YcQagHDqnmBeU3F2ePhWvQmyhPwIJaArk4xGLdv9Imkr3cO8vVapO48k/R9ZRSA
# EBxzd0xMDdZ6+xxFlZJIONRlxcVNNVB30e74Kk08/t82S9ogqgA1Q7KZ2tFuaRes
# jJWuoJ+LtE5lrtknqgaXLb3XH0hV5M0AWRk9Wg/1thb9NCsKEIAdpdnolZOephIz
# fzHiOSqeJ+e5qURLB7rT+F5y0NNWTdqoJ/vOOCUa8z0NKWsz2IkpeD3iNhVCLRKw
# Ojm/wzxdG2tst5OHRZFEwKcxggIDMIIB/wIBATBiMFoxCzAJBgNVBAYTAlVTMRgw
# FgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMD
# UEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNTkCBAMCBNcwCQYFKw4DAhoFAKB4MBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYE
# FOWP2EnBmG1X67y4xFzFY3DKbYYiMA0GCSqGSIb3DQEBAQUABIIBAB+sPANaodcv
# IS5sldAWMg+kYZ5URUK6rIKcWeV7mqEqej+may3+5Md5npQJUV3kdYqWW9kKUYGm
# RdpTEt7j+v01M0YPFAfo00S9WzJ0VatkTQ6z7jahv1P7Z2ZSpr0B+nWA/kh3Vfmp
# SB6HDX4fzD5WO5uipTbam+g20fujE+IzbA8LdxJ+KUyOJB7SVj5mt+YLVj/8a4S1
# ZsTEGd/6KIyp/bCuM0uCkvNtxrMUYQfaga+6BXHjLG+eIgULm18E49szEffFsmBI
# 8qreqczMSbLwuWI/fFkEhWNuDMRPTqXSU8tSf2cWp4C6uzBRU72cqrbCE21wBsbH
# w6mFVVEJGj4=
# SIG # End signature block
