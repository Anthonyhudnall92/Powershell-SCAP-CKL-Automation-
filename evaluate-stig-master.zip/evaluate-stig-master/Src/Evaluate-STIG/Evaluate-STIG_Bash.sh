#!/bin/bash
#Evaluate-STIG on Linux using Bash

function usage() {
cat << EOF
--ScanType <"Unclassified"/"Classified">
        Use to instruct Evaluate-STIG the classification of the asset.  Valid ScanTypes are "Unclassified" and "Classified".  If not specified, default will be "Unclassified".

--VulnTimeout <int>
        Maximum time in minutes to allow a singular Vuln ID check to run.

--AnswerKey <String>
        Use to instruct Evaluate-STIG which Answer Key to use for determining if a comment from an answer file should be applied.  Answer Keys are per Vuln ID and user-defined within the answer file.  If not specified, default Answer Key will be "DEFAULT".  Refer to documentation for more information.

--AFPath <String>
        Path to Answer Files.  If not specified, defaults to \$PsScriptRoot\\AnswerFiles.

--OutputPath <String>
        Sets the directory path for Evaluate-STIG to save its results.  May be a local or UNC path.  If not specified, default path will be C:\\Users\\Public\\Public Documents or \\opt\\.

--SelectSTIG <String>
        Specify which STIG(s) to scan.  For multiple STIGs, separate with commas.  Cannot be specified with -ExcludeSTIG.

--ExcludeSTIG <String>
        Specify which STIG(s) to exclude from the scan.  For multiple STIGs, separate with commas.  Cannot be specified with -SelectSTIG.

-SelectVuln <String>
        Specify which Vulnerabilities(s) to scan (V-#####).  For multiple Vulnerabilities, separate with commas.  Can only be used with -SelectSTIG.

-ExcludeVuln <String>
        Specify which Vulnerabilities(s) to exclude from a scan (V-#####).  For multiple Vulnerabilities, separate with commas.  Can only be used with -SelectSTIG.

--Proxy <String>
        Configure proxy for use with --Update and --DownloadPS

--NoPrevious
        Disable moving current CKLs to Previous folder.

--ApplyTattoo
        Applies Evaluate-STIG tattooing on system.  Mainly for providing a detection method to configuration management tools.

--ListSupportedProducts
        Lists all products that Evaluate-STIG currently supports.

--ListApplicableProducts
        Lists all Evaluate-STIG supported STIGs that are applicable to the asset.

--Version
        Display Evaluate-STIG version and running path.

--Update
        Downloads updates to Evaluate-STIG from the Evaluate-STIG repo on SPORK.

--DownloadPS
		Specify whether or not to download PowerShell binary archive automatically. Script exits after download.
EOF

exit 1
}

SHELLNOCASEMATCH=$(shopt -p nocasematch; true)
shopt -s nocasematch
optspec=":h-:"
while getopts "$optspec" args; do
	case "${args}" in
		-)
			case ${OPTARG} in
				ScanType) ScanType="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
				AnswerKey) AnswerKey="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
				AFPath) AFPath="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
				OutputPath) OutputPath="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
				SelectSTIG) SelectSTIG="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
				ExcludeSTIG) ExcludeSTIG="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
				VulnTimeout) VulnTimeout="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
				Proxy) Proxy="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
				CheckVuln) CheckVuln="${!OPTIND}"; OPTIND=$(( $OPTIND +1 )) ;;
                NoPrevious) NoPrevious=true ;;
				ApplyTattoo) ApplyTattoo=true ;;
                ListSupportedProducts) ListSupportedProducts=true ;;
                ListApplicableProducts) ListApplicableProducts=true ;;
                Version) Version=true ;;
				Update) Update=true ;;
				DownloadPS) DownloadPS=true ;;
				Help) usage ;;
				*)
					echo "Error in command line parsing.  Incorrect switch used." >&2
					exit 1
			esac;;
		h)
			usage ;;
		help)
			usage ;;
		*)
			echo "Error in second command line parsing (2 tacks?)" >&2
            exit 1
	esac
done

$SHELLNOCASEMATCH

if (($EUID != 0)); then
	echo "Must be run with sudo privileges."
	exit 1
fi

ESArgs=""
ESPATH="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ESUSER=$(logname)
SIMPHOST=$(hostname -s)
VERSION_LIMIT=3.0
CURRENT_VERSION=$(uname -r | cut -c1-3)

#Check for noexec
MOUNT_MODE=`findmnt -T $ESPATH | grep noexec`
if [[ ! -z "$MOUNT_MODE" ]]; then
        echo "Must be run from a partition mounted without 'noexec'"
        exit 1
fi

if [ "$DownloadPS" = "true" ]; then
	if [[ $Proxy = "" ]]; then
		LATEST_RELEASE=$(curl --retry 5 --retry-delay 5 -L -s -H 'Accept: application/json' https://github.com/PowerShell/PowerShell/releases/latest)
	else
		LATEST_RELEASE=$(curl --retry 5 --retry-delay 5 -L --proxy $Proxy -s -H 'Accept: application/json' https://github.com/PowerShell/PowerShell/releases/latest)
	fi

	LATEST_VERSION=$(echo "$LATEST_RELEASE" | sed -e 's/.*"tag_name":"\([^"]*\)".*/\1/')
	ARTIFACT_URL="https://github.com/PowerShell/PowerShell/releases/download/$LATEST_VERSION/powershell$(echo $LATEST_VERSION | tr v -)-linux-x64.tar.gz"

	if [ -f "$ESPATH/powershell.tar.gz" ] ; then rm $ESPATH/powershell.tar.gz; fi
	if [[ $Proxy = "" ]]; then
		if ! curl --retry 5 --retry-delay 5 -L -o $ESPATH/powershell.tar.gz $ARTIFACT_URL; then
			echo "PowerShell archive failed to download."
			exit 1
		fi
	else
		if ! curl -L --retry 5 --retry-delay 5 --proxy $Proxy -o $ESPATH/powershell.tar.gz $ARTIFACT_URL; then
			echo "PowerShell archive failed to download."
			exit 1
		fi
	fi
	exit 0
fi

if (( $(echo "$CURRENT_VERSION < $VERSION_LIMIT" | bc -l) )); then
    echo "Kernel version not supported. "
	exit 1
fi

if ! ldconfig -p | grep -qs libicu ; then
  echo "'libicu' not found. Please install 'libicu'"
fi

POWERSHELL=$(find -H $ESPATH -name powershell.tar.gz)

if [[ ! $ScanType = "" ]]; then ESArgs+=" -ScanType $ScanType"; fi
if [[ ! $AnswerKey = "" ]]; then ESArgs+=" -AnswerKey $AnswerKey"; fi
if [[ ! $AFPath = "" ]]; then ESArgs+=" -AFPath $AFPath"; fi
if [[ ! $OutputPath = "" ]]; then ESArgs+=" -OutputPath $OutputPath"; fi
if [[ ! $SelectSTIG = "" ]]; then ESArgs+=" -SelectSTIG $SelectSTIG"; fi
if [[ ! $ExcludeSTIG = "" ]]; then ESArgs+=" -ExcludeSTIG $ExcludeSTIG"; fi
if [[ ! $VulnTimeout = "" ]]; then ESArgs+=" -VulnTimeout $VulnTimeout"; fi
if [[ ! $Proxy = "" ]]; then ESArgs+=" -Proxy $Proxy"; fi
if [[ ! $SelectVuln = "" ]]; then ESArgs+=" -SelectVuln $SelectVuln"; fi
if [[ ! $ExcludeVuln = "" ]]; then ESArgs+=" -ExcludeVuln $ExcludeVuln"; fi
if [[ ! $NoPrevious = "" ]]; then ESArgs+=" -NoPrevious"; fi
if [[ ! $ApplyTattoo = "" ]]; then ESArgs+=" -ApplyTattoo"; fi

if [ -d "$ESPATH/powershell" ]; then
	rm -rf $ESPATH/powershell
fi

if [ -z "$POWERSHELL" ]; then
	echo "Prerequisite failed.  PowerShell binary archive not found in $ESPATH."
	echo "Use the '--DownloadPS' switch or download tar.gz archive and place in $ESPATH."
	echo "https://docs.microsoft.com/en-us/powershell/scripting/install/install-other-linux?view=powershell-7.2#binary-archives"
	exit 1
fi

mkdir $ESPATH/powershell

tar zxf $POWERSHELL -C $ESPATH/powershell

if [ "$ListSupportedProducts" = "true" ]; then
    ESArgs=" -ListSupportedProducts";
	$ESPATH/powershell/pwsh $ESPATH/Evaluate-STIG.ps1 $ESArgs
elif [ "$ListApplicableProducts" = "true" ]; then
	ESArgs=" -ListApplicableProducts";
	$ESPATH/powershell/pwsh $ESPATH/Evaluate-STIG.ps1 $ESArgs
elif [ "$Version" = "true" ]; then
	ESArgs=" -Version";
	$ESPATH/powershell/pwsh $ESPATH/Evaluate-STIG.ps1 $ESArgs
elif [ "$Update" = "true" ]; then
	ESArgs=" -Update";
	$ESPATH/powershell/pwsh $ESPATH/Evaluate-STIG.ps1 $ESArgs
else
	$ESPATH/powershell/pwsh $ESPATH/Evaluate-STIG.ps1 $ESArgs && if [[ $OutputPath ]]; then chown -R $ESUSER: $OutputPath/${SIMPHOST^^}; else chown -R $ESUSER: /opt/STIG_Compliance; fi; rm -rf $ESPATH/powershell
fi