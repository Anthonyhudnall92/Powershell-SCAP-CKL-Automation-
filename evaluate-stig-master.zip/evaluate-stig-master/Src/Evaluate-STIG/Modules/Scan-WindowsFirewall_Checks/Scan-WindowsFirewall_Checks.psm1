##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Microsoft Windows Firewall with Advanced Security
# Version:  V2R1
# Class:    UNCLASSIFIED
# Updated:  8/9/2022
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Confirm-FWProfileEnabled {
    Param (
        [Parameter(Mandatory = $true)]
        [ValidateSet("Domain", "Private", "Public")]
        [String]$Profile
    )

    Switch ($Profile) {
        "Domain" {
            $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"  # Registry path identified in STIG
            $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"  # Registry path identified in STIG
        }
        "Private" {
            $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile"  # Registry path identified in STIG
            $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"  # Registry path identified in STIG
        }
        "Public" {
            $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
            $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"  # Registry path identified in STIG
        }
    }

    $ProfileValueName = "EnableFirewall"  # Value name identified in STIG
    $ProfileValue = "1"  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $Enabled = $false

    $Profile1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $ProfileValueName
    $Profile2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $ProfileValueName

    If ($Profile1.Value -eq $ProfileValue -and $Profile1.Type -eq $RegistryType) {
        $Enabled = $true
    }
    ElseIf ($Profile1.Value -eq "(NotFound)" -and $Profile2.Value -eq $ProfileValue -and $Profile2.Type -eq $RegistryType) {
        $Enabled = $true
    }

    Return $Enabled
}

Function Get-V241989 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241989
        STIG ID    : WNFWA-000001
        Rule ID    : SV-241989r698208_rule
        CCI ID     : CCI-001414
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must be enabled when connected to a domain.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"  # Registry path identified in STIG
    $ProfileValueName = "EnableFirewall"  # Value name identified in STIG
    $ProfileValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true

    If ((Get-CimInstance Win32_ComputerSystem).DomainRole -notin @("1", "3", "4", "5")) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is not a member of a domain so this requirement is NA." | Out-String
    }
    Else {
        $Profile1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $ProfileValueName
        $Profile2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $ProfileValueName

        # Format the DWORD values
        If ($Profile1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Profile1Value = "0x{0:x8}" -f $Profile1.Value + " ($($Profile1.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Profile1Value = $Profile1.Value
        }

        If ($Profile2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Profile2Value = "0x{0:x8}" -f $Profile2.Value + " ($($Profile2.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Profile2Value = $Profile2.Value
        }

        # Check if profile is enabled
        If ($Profile1.Type -eq "(NotFound)") {
            If ($Profile2.Value -in $ProfileValue -and $Profile2.Type -eq $RegistryType) {
                # Profile is enabled
                $ProfileEnabled = "Enabled"
            }
            Else {
                # Profile is disabled
                $ProfileEnabled = "Disabled (Finding)"
                $Compliant = $false
            }
        }
        ElseIf ($Profile1.Value -in $ProfileValue -and $Profile1.Type -eq $RegistryType) {
            # Profile is enabled
            $ProfileEnabled = "Enabled"
        }
        Else {
            # Profile is disabled
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
        $FindingDetails += "Value:`t`t$Profile1Value" | Out-String
        $FindingDetails += "Type:`t`t$($Profile1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
        $FindingDetails += "Value:`t`t$Profile2Value" | Out-String
        $FindingDetails += "Type:`t`t$($Profile2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241990 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241990
        STIG ID    : WNFWA-000002
        Rule ID    : SV-241990r698211_rule
        CCI ID     : CCI-001414
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must be enabled when connected to a private network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"  # Registry path identified in STIG
    $ProfileValueName = "EnableFirewall"  # Value name identified in STIG
    $ProfileValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true

    $Profile1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $ProfileValueName
    $Profile2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $ProfileValueName

    # Format the DWORD values
    If ($Profile1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Profile1Value = "0x{0:x8}" -f $Profile1.Value + " ($($Profile1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Profile1Value = $Profile1.Value
    }

    If ($Profile2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Profile2Value = "0x{0:x8}" -f $Profile2.Value + " ($($Profile2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Profile2Value = $Profile2.Value
    }

    # Check if profile is enabled
    If ($Profile1.Type -eq "(NotFound)") {
        If ($Profile2.Value -in $ProfileValue -and $Profile2.Type -eq $RegistryType) {
            # Profile is enabled
            $ProfileEnabled = "Enabled"
        }
        Else {
            # Profile is disabled
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }
    }
    ElseIf ($Profile1.Value -in $ProfileValue -and $Profile1.Type -eq $RegistryType) {
        # Profile is enabled
        $ProfileEnabled = "Enabled"
    }
    Else {
        # Profile is disabled
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
    $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
    $FindingDetails += "Value:`t`t$Profile1Value" | Out-String
    $FindingDetails += "Type:`t`t$($Profile1.Type)" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
    $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
    $FindingDetails += "Value:`t`t$Profile2Value" | Out-String
    $FindingDetails += "Type:`t`t$($Profile2.Type)" | Out-String
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241991 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241991
        STIG ID    : WNFWA-000003
        Rule ID    : SV-241991r698214_rule
        CCI ID     : CCI-001414
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must be enabled when connected to a public network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"  # Registry path identified in STIG
    $ProfileValueName = "EnableFirewall"  # Value name identified in STIG
    $ProfileValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true

    $Profile1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $ProfileValueName
    $Profile2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $ProfileValueName

    # Format the DWORD values
    If ($Profile1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Profile1Value = "0x{0:x8}" -f $Profile1.Value + " ($($Profile1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Profile1Value = $Profile1.Value
    }

    If ($Profile2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Profile2Value = "0x{0:x8}" -f $Profile2.Value + " ($($Profile2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Profile2Value = $Profile2.Value
    }

    # Check if profile is enabled
    If ($Profile1.Type -eq "(NotFound)") {
        If ($Profile2.Value -in $ProfileValue -and $Profile2.Type -eq $RegistryType) {
            # Profile is enabled
            $ProfileEnabled = "Enabled"
        }
        Else {
            # Profile is disabled
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }
    }
    ElseIf ($Profile1.Value -in $ProfileValue -and $Profile1.Type -eq $RegistryType) {
        # Profile is enabled
        $ProfileEnabled = "Enabled"
    }
    Else {
        # Profile is disabled
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
    $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
    $FindingDetails += "Value:`t`t$Profile1Value" | Out-String
    $FindingDetails += "Type:`t`t$($Profile1.Type)" | Out-String
    $FindingDetails += "" | Out-String
    $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
    $FindingDetails += "Value Name:`t$ProfileValueName" | Out-String
    $FindingDetails += "Value:`t`t$Profile2Value" | Out-String
    $FindingDetails += "Type:`t`t$($Profile2.Type)" | Out-String
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241992 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241992
        STIG ID    : WNFWA-000004
        Rule ID    : SV-241992r698217_rule
        CCI ID     : CCI-000382
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must block unsolicited inbound connections when connected to a domain.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultInboundAction"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    If ((Get-CimInstance Win32_ComputerSystem).DomainRole -notin @("1", "3", "4", "5")) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is not a member of a domain so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241993 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241993
        STIG ID    : WNFWA-000005
        Rule ID    : SV-241993r698220_rule
        CCI ID     : CCI-001094
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must allow outbound connections, unless a rule explicitly blocks the connection when connected to a domain.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultOutboundAction"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    If ((Get-CimInstance Win32_ComputerSystem).DomainRole -notin @("1", "3", "4", "5")) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is not a member of a domain so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241994 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241994
        STIG ID    : WNFWA-000009
        Rule ID    : SV-241994r698223_rule
        CCI ID     : CCI-000140
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security log size must be configured for domain connections.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogFileSize"  # Value name identified in STIG
    $SettingValue = "16384"  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    If ((Get-CimInstance Win32_ComputerSystem).DomainRole -notin @("1", "3", "4", "5")) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is not a member of a domain so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -ge $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -ge $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241995 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241995
        STIG ID    : WNFWA-000010
        Rule ID    : SV-241995r698226_rule
        CCI ID     : CCI-000172
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security must log dropped packets when connected to a domain.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogDroppedPackets"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    If ((Get-CimInstance Win32_ComputerSystem).DomainRole -notin @("1", "3", "4", "5")) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is not a member of a domain so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241996 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241996
        STIG ID    : WNFWA-000011
        Rule ID    : SV-241996r698229_rule
        CCI ID     : CCI-001462
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security must log successful connections when connected to a domain.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogSuccessfulConnections"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Domain Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    If ((Get-CimInstance Win32_ComputerSystem).DomainRole -notin @("1", "3", "4", "5")) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is not a member of a domain so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
        $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting2Value = $Setting2.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Domain) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Type -eq "(NotFound)") {
            If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
                # Setting is configured
                $CompliantSetting.Value = $Setting2Value
                $CompliantSetting.Type = $Setting2.Type
            }
            Else {
                # Setting is not configured
                $Compliant = $false
            }
        }
        ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
            $FindingDetails += "" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241997 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241997
        STIG ID    : WNFWA-000012
        Rule ID    : SV-241997r698232_rule
        CCI ID     : CCI-000382
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must block unsolicited inbound connections when connected to a private network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultInboundAction"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241998 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241998
        STIG ID    : WNFWA-000013
        Rule ID    : SV-241998r698235_rule
        CCI ID     : CCI-001094
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must allow outbound connections, unless a rule explicitly blocks the connection when connected to a private network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultOutboundAction"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V241999 {
    <#
    .DESCRIPTION
        Vuln ID    : V-241999
        STIG ID    : WNFWA-000017
        Rule ID    : SV-241999r698238_rule
        CCI ID     : CCI-000140
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security log size must be configured for private network connections.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogFileSize"  # Value name identified in STIG
    $SettingValue = "16384"  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -ge $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -ge $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242000 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242000
        STIG ID    : WNFWA-000018
        Rule ID    : SV-242000r698241_rule
        CCI ID     : CCI-000172
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security must log dropped packets when connected to a private network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogDroppedPackets"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242001 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242001
        STIG ID    : WNFWA-000019
        Rule ID    : SV-242001r698244_rule
        CCI ID     : CCI-001462
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security must log successful connections when connected to a private network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PrivateProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogSuccessfulConnections"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Private Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Private) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242002 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242002
        STIG ID    : WNFWA-000020
        Rule ID    : SV-242002r698247_rule
        CCI ID     : CCI-000382
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must block unsolicited inbound connections when connected to a public network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultInboundAction"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242003 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242003
        STIG ID    : WNFWA-000021
        Rule ID    : SV-242003r698250_rule
        CCI ID     : CCI-001094
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : The Windows Firewall with Advanced Security must allow outbound connections, unless a rule explicitly blocks the connection when connected to a public network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"  # Registry path identified in STIG
    $SettingValueName = "DefaultOutboundAction"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242004 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242004
        STIG ID    : WNFWA-000024
        Rule ID    : SV-242004r698253_rule
        CCI ID     : CCI-001190
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security local firewall rules must not be merged with Group Policy settings when connected to a public network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $SettingValueName = "AllowLocalPolicyMerge"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    If ((Get-CimInstance Win32_ComputerSystem).DomainRole -notin @("1", "3", "4", "5")) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is not a member of a domain so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Public) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242005 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242005
        STIG ID    : WNFWA-000025
        Rule ID    : SV-242005r698256_rule
        CCI ID     : CCI-001190
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security local connection rules must not be merged with Group Policy settings when connected to a public network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile"  # Registry path identified in STIG
    $SettingValueName = "AllowLocalIPsecPolicyMerge"  # Value name identified in STIG
    $SettingValue = @("0")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    If ((Get-CimInstance Win32_ComputerSystem).DomainRole -notin @("1", "3", "4", "5")) {
        $Status = "Not_Applicable"
        $FindingDetails += "System is not a member of a domain so this requirement is NA." | Out-String
    }
    Else {
        $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName

        # Format the DWORD values
        If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
            $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
        }
        Else {
            $Setting1Value = $Setting1.Value
        }

        # Check if profile is enabled
        If (Confirm-FWProfileEnabled -Profile Public) {
            $ProfileEnabled = "Enabled"
        }
        Else {
            $ProfileEnabled = "Disabled (Finding)"
            $Compliant = $false
        }

        # Check if setting is configured
        If ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting1Value
            $CompliantSetting.Type = $Setting1.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }

        Switch ($Compliant) {
            $true {
                $Status = "NotAFinding"
            }
            $false {
                $Status = "Open"
            }
        }

        $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
        $FindingDetails += "" | Out-String
        If ($CompliantSetting.Value) {
            $FindingDetails += "Compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
            $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
        }
        Else {
            $FindingDetails += "No compliant setting found:" | Out-String
            $FindingDetails += "---------------------------" | Out-String
            $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
            $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
            $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
            $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242006 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242006
        STIG ID    : WNFWA-000027
        Rule ID    : SV-242006r698259_rule
        CCI ID     : CCI-000140
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security log size must be configured for public network connections.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogFileSize"  # Value name identified in STIG
    $SettingValue = "16384"  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -ge $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -ge $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242007 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242007
        STIG ID    : WNFWA-000028
        Rule ID    : SV-242007r698262_rule
        CCI ID     : CCI-000172
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security must log dropped packets when connected to a public network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogDroppedPackets"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242008 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242008
        STIG ID    : WNFWA-000029
        Rule ID    : SV-242008r698265_rule
        CCI ID     : CCI-001462
        Rule Name  : SRG-OS-000327-GPOS-00127
        Rule Title : The Windows Firewall with Advanced Security must log successful connections when connected to a public network.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $RegistryPath1 = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\PublicProfile\Logging"  # Registry path identified in STIG
    $RegistryPath2 = "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile\Logging"  # Registry path identified in STIG
    $SettingValueName = "LogSuccessfulConnections"  # Value name identified in STIG
    $SettingValue = @("1")  # Value(s) expected in STIG
    $RegistryType = "REG_DWORD"  # Value type expected in STIG
    $ProfileName = "Public Profile"
    $Compliant = $true
    $CompliantSetting = @{ }

    $Setting1 = Get-RegistryResult -Path $RegistryPath1 -ValueName $SettingValueName
    $Setting2 = Get-RegistryResult -Path $RegistryPath2 -ValueName $SettingValueName

    # Format the DWORD values
    If ($Setting1.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting1Value = "0x{0:x8}" -f $Setting1.Value + " ($($Setting1.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting1Value = $Setting1.Value
    }

    If ($Setting2.Type -in @("REG_DWORD", "REG_QWORD")) {
        $Setting2Value = "0x{0:x8}" -f $Setting2.Value + " ($($Setting2.Value))" # Convert to hex and fomat to 0x00000000
    }
    Else {
        $Setting2Value = $Setting2.Value
    }

    # Check if profile is enabled
    If (Confirm-FWProfileEnabled -Profile Public) {
        $ProfileEnabled = "Enabled"
    }
    Else {
        $ProfileEnabled = "Disabled (Finding)"
        $Compliant = $false
    }

    # Check if setting is configured
    If ($Setting1.Type -eq "(NotFound)") {
        If ($Setting2.Value -in $SettingValue -and $Setting2.Type -eq $RegistryType) {
            # Setting is configured
            $CompliantSetting.Value = $Setting2Value
            $CompliantSetting.Type = $Setting2.Type
        }
        Else {
            # Setting is not configured
            $Compliant = $false
        }
    }
    ElseIf ($Setting1.Value -in $SettingValue -and $Setting1.Type -eq $RegistryType) {
        # Setting is configured
        $CompliantSetting.Value = $Setting1Value
        $CompliantSetting.Type = $Setting1.Type
    }
    Else {
        # Setting is not configured
        $Compliant = $false
    }

    Switch ($Compliant) {
        $true {
            $Status = "NotAFinding"
        }
        $false {
            $Status = "Open"
        }
    }

    $FindingDetails += "$ProfileName is $ProfileEnabled" | Out-String
    $FindingDetails += "" | Out-String
    If ($CompliantSetting.Value) {
        $FindingDetails += "Compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($CompliantSetting.Value)" | Out-String
        $FindingDetails += "Type:`t`t$($CompliantSetting.Type)" | Out-String
    }
    Else {
        $FindingDetails += "No compliant setting found:" | Out-String
        $FindingDetails += "---------------------------" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath1" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting1Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting1.Type)" | Out-String
        $FindingDetails += "" | Out-String
        $FindingDetails += "Registry Path:`t$RegistryPath2" | Out-String
        $FindingDetails += "Value Name:`t$SettingValueName" | Out-String
        $FindingDetails += "Value:`t`t$($Setting2Value)" | Out-String
        $FindingDetails += "Type:`t`t$($Setting2.Type)" | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

Function Get-V242009 {
    <#
    .DESCRIPTION
        Vuln ID    : V-242009
        STIG ID    : WNFWA-000100
        Rule ID    : SV-242009r698268_rule
        CCI ID     : CCI-000067
        Rule Name  : SRG-OS-000480-GPOS-00227
        Rule Title : Inbound exceptions to the firewall on domain workstations must only allow authorized remote management hosts.
    #>

    Param (
        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $true)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Username,

        [Parameter(Mandatory = $false)]
        [String]$UserSID
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $VulnID = ($MyInvocation.MyCommand.Name).Replace("Get-V", "V-")
    $Status = "Not_Reviewed"  #acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $Severity = "" #acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.

    If ($AnswerFile) {
        $AnswerData = (Get-CorporateComment -AnswerFile $AnswerFile -VulnID $VulnID -AnswerKey $AnswerKey -UserSID $UserSID)
    }

    #---=== Begin Custom Code ===---#
    $DomainRole = (Get-CimInstance Win32_ComputerSystem).DomainRole
    If ($DomainRole -in @("0", "2", "3", "4", "5")) {
        $Status = "Not_Applicable"
        Switch ($DomainRole) {
            "0" {
                $RoleText = "Standalone Workstation"
            }
            "2" {
                $RoleText = "Standalone Server"
            }
            "3" {
                $RoleText = "Member Server"
            }
            "4" {
                $RoleText = "Backup Domain Controller"
            }
            "5" {
                $RoleText = "Primary Domain Controller"
            }
        }
        $FindingDetails += "System is a $RoleText so this requirement is NA." | Out-String
    }
    #---=== End Custom Code ===---#

    If ($Status -eq $AnswerData.ExpectedStatus) {
        $AFKey = $AnswerData.AFKey
        $AFStatus = $AnswerData.AFStatus
        $Comments = $AnswerData.AFComment | Out-String
    }

    Return Send-CheckResult -Module $([String]$ModuleName) -Status $([String]$Status) -FindingDetails $([String]$FindingDetails) -AFKey $([String]$AFKey) -AFStatus $([String]$AFStatus) -Comments $([String]$Comments) -Severity $([String]$Severity)
}

# SIG # Begin signature block
# MIIL1AYJKoZIhvcNAQcCoIILxTCCC8ECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU3gpb7OkJVuLY5OUhBoGy43To
# yPagggk7MIIEejCCA2KgAwIBAgIEAwIE1zANBgkqhkiG9w0BAQsFADBaMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MB4XDTIwMDcxNTAw
# MDAwMFoXDTI1MDQwMjEzMzgzMlowaTELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1Uu
# Uy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxDDAKBgNV
# BAsTA1VTTjEWMBQGA1UEAxMNQ1MuTlNXQ0NELjAwMTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANv2fdTmx2dNPQ47F8kmvU+g20/sFoF+DS3k2GcMduuI
# XxYFJyMMPAvTJuobeJlX6P6sr5jAKhXXsoV4lT2boWw583Snl6cuSfqMbVowIJ1s
# CffN7N0VXsLVdOt1u5GCKs4/jXH7MeEOE0oJsgEjjE1IZc5tEqj++s1N1EUY+jf/
# zc8QHDjy5X88XBTzKVhwvczZVbRahrcmYv0k4we3ndwTl5nXYizSwi96CZuqzrIn
# WbLSsRLNyNZZVo7J5bZ+30dv/hZvq6FqxfAeM3pEDrvbfFkWXzaISqF1bVbsMlAC
# UBf/JFbSGtmMsU1ABfXKPalTWYJKP58dICHcUocZhL0CAwEAAaOCATcwggEzMB8G
# A1UdIwQYMBaAFHUJphUTroc8+nOUAPLw9Xm5snIUMEEGA1UdHwQ6MDgwNqA0oDKG
# MGh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNTlfTkNPREVTSUdOLmNy
# bDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyowHQYDVR0O
# BBYEFFbrF3OpzfdsZkN1zTfv++oaLCRRMGUGCCsGAQUFBwEBBFkwVzAzBggrBgEF
# BQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNTkuY2VyMCAG
# CCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAWBgorBgEE
# AYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAQknaIAXDnyqshmyh
# uOZS4nBtSydnZrdB8Je0JCq2TTRA4dkNvrswe0kZgA7UjlY1X/9PtQeIwaMrcvdF
# i+dqzD1bbW/LX5tH/1oMOp4s+VkGfl4xUUxUGjO6QTVOeLyN2x+DBQU11DhKEq9B
# RCxUGgclFn1iqxi5xKmLaQ3XuRWRGCkb+rXejWR+5uSTognxCuoLp95bqu3JL8ec
# yF46+VSoafktAGot2Uf3qmwWdMHFBdwzmJalbC4j09I1qJqcJH0p8Wt34zRw/hSr
# 3f+xDEDP8GNL2ciDm7aN0GKy67ugjgMmPXAv7A4/keCuN/dsNS1naNyqzc5AhTAF
# +o/21jCCBLkwggOhoAMCAQICAgMFMA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTE5MDQwMjEzMzgz
# MloXDTI1MDQwMjEzMzgzMlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4g
# R292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMT
# DERPRCBJRCBDQS01OTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMwX
# hJ8twQpXrRFNNVc/JEcvHA9jlr27cDE8rpxWkobvpCJOoOVUbJ724Stx6OtTAZpR
# iXNaS0jjRgYaW6cq9pdnjjQM5ovHPPde1ewaZyWb2I+uqhkZmOBV1+lGUOhnQCyi
# nnSSqzEH1PC5nASfyxnCdBeOt+UKHBrPVKBUuYS4Fcn5Q0wv+sfBD24vyV5Ojeoq
# HeSSAMTaeqlv+WQb4YrjKNfaGF+S7lMvQelu3ANHEcoL2HMCimCvnCHQaMQI9+Ms
# NhySPEULePdEDxgpWYc9FmBbjUp1CYEx7HYdlTRJ9gBHts2ITxTZQrt4Epjkqeb8
# aWVmzCEPHE7+KUVhuO8CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyKlKJ3sYBy
# HYF6Fqry3M5m7kXAMB0GA1UdDgQWBBR1CaYVE66HPPpzlADy8PV5ubJyFDAOBgNV
# HQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsn
# MAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgB
# ZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQE
# BTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3Js
# L0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0
# cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3YzAgBggr
# BgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQELBQADggEB
# ADkFG9IOpz71qHNXCeYJIcUshgN20CrvB5ym4Pr7zKTBRMKNqd9EXWBxrwP9xhra
# 5YcQagHDqnmBeU3F2ePhWvQmyhPwIJaArk4xGLdv9Imkr3cO8vVapO48k/R9ZRSA
# EBxzd0xMDdZ6+xxFlZJIONRlxcVNNVB30e74Kk08/t82S9ogqgA1Q7KZ2tFuaRes
# jJWuoJ+LtE5lrtknqgaXLb3XH0hV5M0AWRk9Wg/1thb9NCsKEIAdpdnolZOephIz
# fzHiOSqeJ+e5qURLB7rT+F5y0NNWTdqoJ/vOOCUa8z0NKWsz2IkpeD3iNhVCLRKw
# Ojm/wzxdG2tst5OHRZFEwKcxggIDMIIB/wIBATBiMFoxCzAJBgNVBAYTAlVTMRgw
# FgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMD
# UEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNTkCBAMCBNcwCQYFKw4DAhoFAKB4MBgG
# CisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcC
# AQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYE
# FIWx1zIxRZOkK3zUXSF1lBx3hcYEMA0GCSqGSIb3DQEBAQUABIIBAEWMRAiDLx/4
# v/pfZICHHhlXAHbspeHGSWiCGGspVlVRo56TqpvvBrnuXT2+WY/tT3df2mbjAUqz
# MElBS/823QBlIp3lTkX+iS9hCypxIZ4TkMAxeJ8KSJuWRrkSHAe2Lrg1+SsZR3rR
# Yc3jwoZqSRwrRPesEF8K3Gx1zhRjZN211IIeU43OnuvEEnBA4U0Lixv+Wrfvomvl
# sbsn2Dkat20YtvczSBOr17eL+VBgWLIbOOZvdEDHdmxpAByDy17XFhsGX9nal/kT
# oij/XmqWCyNAvBnFZio2dl6OL60rQgihP3K2dU8YLKJIxYDoksDswjAB0cXAJipf
# bWKZHLqGejU=
# SIG # End signature block
