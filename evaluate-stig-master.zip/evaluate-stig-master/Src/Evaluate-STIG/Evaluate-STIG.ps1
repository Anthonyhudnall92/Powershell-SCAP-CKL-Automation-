# ###############################################################
# # Title:        Evaluate-STIG
# # Version:      1.2210.1
# # Description:  Automates STIG checklist (CKL) creation
# # Date:         11/17/2022
# ###############################################################

#requires -version 5.1

<#
    .Synopsis
        Automatically creates STIG checklists (CKL).
    .DESCRIPTION
        Automates the documentation of STIG compliance into STIG Viewer compatible checklist (.ckl) files.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1

        Runs Evaluate-STIG with default settings ("Unclassified" ScanType, "DEFAULT" Answer Key, and output to C:\Users\Public\Public Documents)
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -ScanType Classified -AnswerKey TestNetwork

        Runs Evaluate-STIG for a classified system and instructs it to use the user defined "TestNetwork" Answer Key.  Refer to documentation on answer keys.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -OutputPath E:\STIGResults

        Runs Evaluate-STIG for an unclassified asset using the DEFAULT answer key and outputs to E:\STIGResults
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -ScanType Classified -ComputerName Workstation1

        Executes Classified scan on remote computer Workstation1.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -ComputerName Workstation1,Workstation2,C:\Computers.txt -AltCredential -ThrottleLimit 7

        Executes Unclassifed scan on multiple computer names and a list of computers using an alternate credential and limiting concurrent scans to 7.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -SelectSTIG MSEdge,JavaJRE8,Win10

        Selects Microsoft Edge, Java JRE8, and Windows 10 (by shortname) to be scanned.
    .EXAMPLE
        PS C:\> .\Evaluate-STIG.ps1 -ExcludeSTIG DotNET4,WinServer2019

        Excludes .NET 4 Framework and Windows Server 2019 from scan.  All other STIGs will be scanned if applicable.
    .INPUTS
        -ScanType <"Unclassified"/"Classified">
        Use to instruct Evaluate-STIG the classification of the asset.  Valid ScanTypes are "Unclassified" and "Classified".  If not specified, default will be "Unclassified".

        -VulnTimeout <int>
        Maximum time in minutes to allow a singular Vuln ID check to run.

        -AnswerKey <String>
        Use to instruct Evaluate-STIG which Answer Key to use for determining if a comment from an answer file should be applied.  Answer Keys are per Vuln ID and user-defined within the answer file.  If not specified, default Answer Key will be "DEFAULT".  Refer to documentation for more information.

        -AFPath <string>
        Path to Answer Files.  If not specified, defaults to $PsScriptRoot\AnswerFiles.

        -OutputPath <String>
        Sets the directory path for Evaluate-STIG to save its results.  May be a local or UNC path.  If not specified, default path will be C:\Users\Public\Public Documents or \opt\.  If using -OutputPath with -ComputerName, ensure the host computer's account has write access to the path in -OutputPath.

        -SelectSTIG <String>
        Specify which STIG(s) to scan.  Use Tab or CTRL+SPACE to properly select STIG(s) by its short name.  For multiple STIGs, separate with commas.  Cannot be specified with -ExcludeSTIG.

        -ExcludeSTIG <String>
        Specify which STIG(s) to exclude from the scan.  Use Tab or CTRL+SPACE to properly exclude STIG(s) by its short name.  For multiple STIGs, separate with commas.  Cannot be specified with -SelectSTIG.

        -SelectVuln <String>
        Specify which Vulnerabilities(s) to scan (V-#####).  For multiple Vulnerabilities, separate with commas.  Can only be used with -SelectSTIG.

        -ExcludeVuln <String>
        Specify which Vulnerabilities(s) to exclude from a scan (V-#####).  For multiple Vulnerabilities, separate with commas.  Can only be used with -SelectSTIG.

        -ComputerName <String>
        Execute scan on remote computer.  Supports multiple computers through comma separation. Can be a computer name, a file with a list of computers, or a combination.  By default, results will be copied back to source computer.  Requires admin rights on remote computer.

        -ThrottleLimit <int>
        Number of concurrent Evaluate-STIG jobs to run when using -ComputerName.  Default is 10. Requires -ComputerName input.  Windows only.

        -AltCredential
        Prompts for an alternate credential to use for remote scans.  If connection to the remote machine fails with the alternate credential, Evaluate-STIG will fallback to the launching user and attempt the connection - essentially allowing for two credentials to be used for remote scan (e.g. workstation/server credentials).  Requires -ComputerName input.  Windows only.

        -GenerateOQE
        Creates Objective Quality Evidence (OQE) files in output path.

        -NoPrevious
        Disable moving current CKLs to Previous folder.

        -ApplyTattoo
        Applies Evaluate-STIG tattooing on system.  Mainly for providing a detection method to configuration management tools.

        -ListSupportedProducts
        Lists all products that Evaluate-STIG currently supports.

        -ListApplicableProducts
        Lists all Evaluate-STIG supported STIGs that are applicable to the asset.

        -Version
        Display Evaluate-STIG version and running path.

        -Update
        Downloads updates to Evaluate-STIG from the Evaluate-STIG repo on SPORK.

        -Proxy <String>
        Configure proxy for use with -Update.
    .LINK
        Evaluate-STIG
        https://spork.navsea.navy.mil/nswc-crane-division/evaluate-stig
        https://intelshare.intelink.gov/sites/NAVSEA-RMF

        Windows Remote Management (WinRM)
        https://docs.microsoft.com/en-us/windows/win32/winrm

        CMTrace (for viewing EValuate-STIG.log)
        https://docs.microsoft/en-us/configmgr/core/support/cmtrace
    #>

Param (
    [Parameter(Mandatory = $false)]
    [String[]]$ComputerName,

    [Parameter(Mandatory = $false)]
    [ValidateSet("Unclassified", "Classified")]
    [String]$ScanType = "Unclassified",

    [Parameter(Mandatory = $false)]
    [Int]$VulnTimeout = 15,

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String]$AFPath,

    [Parameter(Mandatory = $false)]
    [String]$AnswerKey = "DEFAULT",

    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [String]$OutputPath,

    [Parameter(Mandatory = $false)]
    [Switch]$GenerateOQE,

    [Parameter(Mandatory = $false)]
    [Switch]$NoPrevious,

    [Parameter(Mandatory = $false)]
    [Switch]$ApplyTattoo,

    [Parameter(Mandatory = $false)]
    [Switch]$ListSupportedProducts,

    [Parameter(Mandatory = $false)]
    [Switch]$ListApplicableProducts,

    [Parameter(Mandatory = $false)]
    [Switch]$Version,

    [Parameter(Mandatory = $false)]
    [Switch]$Update,

    # Code for -SelectSTIG Option
    # https://powershell.one/powershell-internals/attributes/autocompletion
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [ArgumentCompleter({
        # Recieve information about current state to assit in auto-completing user typed value
        Param($CommandName, $ParameterName, $WordToComplete, $CommandAst, $FakeBoundParameters)

        # Get STIG ShortNames from STIGList.xml
        $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
        If (Test-Path $STIGListXML) {
            $STIGs = ([XML](Get-Content $STIGListXML)).List.STIG | Select-Object Name,ShortName -Unique | Sort-Object ShortName

            # Compose CompletionResult Entries
            $STIGs | Where-Object {$_.Shortname} | Where-Object {$_.ShortName -like "$WordToComplete*"} | ForEach-Object {
                $STIGSN = $_.Shortname
                If ($STIGSN -like '* *') {
                    $STIGSN = "'$STIGSN'"
                }
                [Management.Automation.CompletionResult]::New($STIGSN,$STIGSN,"ParameterValue",$_.Name)
            }
        }
    })]
    [ValidateScript({
        $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
        If (Test-Path $STIGListXML) {
            $ValidSTIGs = (([XML](Get-Content $STIGListXML)).List.STIG).ShortName
                If ($_ -Match ",") {
                    $_ -Split "," | ForEach-Object {
                        If ($_ -in $ValidSTIGs) {
                            $true
                        }
                        Else {
                            Throw "`r`n `r`n'$_' is not a product supported by Evaluate-STIG.`r`n `r`nPlease use CTRL+SPACE to list valid products.`r`n"
                        }
                    }
                }
            ElseIf ($_ -in $ValidSTIGs) {
                $true
            }
            Else {
                Throw "`r`n `r`n'$_' is not a product supported by Evaluate-STIG.`r`n `r`nPlease use CTRL+SPACE to list valid products.`r`n"
            }
        }
        Else {
            Throw "`r`n `r`n'$STIGListXML' does not exist.  Cannot continue.`r`n `r`n"
        }
    })]
    [Array]$SelectSTIG,

    # Code for -ExcludeSTIG Option
    # https://powershell.one/powershell-internals/attributes/autocompletion
    [Parameter(Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [ArgumentCompleter({
        # Recieve information about current state to assit in auto-completing user typed value
        Param($CommandName, $ParameterName, $WordToComplete, $CommandAst, $FakeBoundParameters)

        # Get STIG ShortNames from STIGList.xml
        $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
        If (Test-Path $STIGListXML) {
            $STIGs = ([XML](Get-Content $STIGListXML)).List.STIG | Select-Object Name,ShortName -Unique | Sort-Object ShortName

            # Compose CompletionResult Entries
            $STIGs | Where-Object {$_.Shortname} | Where-Object {$_.ShortName -like "$WordToComplete*"} | ForEach-Object {
                $STIGSN = $_.Shortname
                If ($STIGSN -like '* *') {
                    $STIGSN = "'$STIGSN'"
                }
                [Management.Automation.CompletionResult]::New($STIGSN,$STIGSN,"ParameterValue",$_.Name)
            }
        }
    })]
    [ValidateScript( {
        $STIGListXML = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
        If (Test-Path $STIGListXML) {
            $ValidSTIGs = (([XML](Get-Content $STIGListXML)).List.STIG).ShortName
            If ($_ -Match ",") {
                $_ -Split "," | ForEach-Object {
                    If ($_ -in $ValidSTIGs) {
                        $true
                    }
                    Else {
                        Throw "`r`n `r`n'$_' is not a product supported by Evaluate-STIG.`r`n `r`nPlease use CTRL+SPACE to list valid products.`r`n"
                    }
                }
            }
            ElseIf ($_ -in $ValidSTIGs) {
                $true
            }
            Else {
                Throw "`r`n `r`n'$_' is not a product supported by Evaluate-STIG.`r`n `r`nPlease use CTRL+SPACE to list valid products.`r`n"
            }
        }
        Else {
            Throw "`r`n `r`n'$STIGListXML' does not exist.  Cannot continue.`r`n `r`n"
        }
    })]
    [Array]$ExcludeSTIG
    )

# Expose addtional dynamic parameters
DynamicParam {
    $ParamDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary

    If ($ComputerName -and (-Not($IsLinux))) {
        # Expose -AltCredential and -ThrottleLimit options if -ComputerName is specified
        $Attributes = New-Object System.Management.Automation.ParameterAttribute
        $Attributes.Mandatory = $false
        $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $AttributeCollection.Add($Attributes)
        $CredParam = New-Object System.Management.Automation.RuntimeDefinedParameter("AltCredential", [Switch], $AttributeCollection)
        $ParamDictionary.Add("AltCredential", $CredParam)

        # Expose -ThrottleLimit
        $Attributes = New-Object System.Management.Automation.ParameterAttribute
        $Attributes.Mandatory = $false
        $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $AttributeCollection.Add($Attributes)
        $ThrottleParam = New-Object System.Management.Automation.RuntimeDefinedParameter("ThrottleLimit", [int], $AttributeCollection)
        $ParamDictionary.Add("ThrottleLimit", $ThrottleParam)
    }

    If ($Update) {
        # Expose -Proxy
        $Attributes = New-Object System.Management.Automation.ParameterAttribute
        $Attributes.Mandatory = $false
        $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $AttributeCollection.Add($Attributes)
        $ProxyParam = New-Object System.Management.Automation.RuntimeDefinedParameter("Proxy", [String], $AttributeCollection)
        $ParamDictionary.Add("Proxy", $ProxyParam)
    }

    If ($SelectSTIG) {
        # Expose -SelectVuln
        $Attributes = New-Object System.Management.Automation.ParameterAttribute
        $Attributes.Mandatory = $false
        $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $AttributeCollection.Add($Attributes)
        $SelectVulnParam = New-Object System.Management.Automation.RuntimeDefinedParameter("SelectVuln", [Array], $AttributeCollection)
        $ParamDictionary.Add("SelectVuln", $SelectVulnParam)

        # Expose -ExcludeVuln
        $Attributes = New-Object System.Management.Automation.ParameterAttribute
        $Attributes.Mandatory = $false
        $AttributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
        $AttributeCollection.Add($Attributes)
        $ExcludeVulnParam = New-Object System.Management.Automation.RuntimeDefinedParameter("ExcludeVuln", [Array], $AttributeCollection)
        $ParamDictionary.Add("ExcludeVuln", $ExcludeVulnParam)
    }

    Return $ParamDictionary
}

Process {
    # -Update and external scripts reference the below $EvaluateStigVersion line as written.  Do not modify.
    $EvaluateStigVersion = "1.2210.1"
    # Scan process uses the below global variable for retaining the version variable across scripts and functions.
    $Global:ESVersion = $EvaluateStigVersion

    # If both -SelectSTIG and -ExcludeSTIG both specified, error out.  Only one may be specified.
    Try {
        If (($SelectSTIG) -and ($ExcludeSTIG)) {
            Throw "-SelectSTIG and -ExcludeSTIG cannot both be specified."
        }
    }
    Catch {
        Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
        Return
    }

    # Create $AltCredential variable if specified in command line
    If ($PsBoundParameters.AltCredential) {
        $AltCredential = "{0}" -f $PsBoundParameters.AltCredential
    }

    If ($PsBoundParameters.SelectVuln) {
        $SelectVuln = $PsBoundParameters.SelectVuln | Sort-Object -Unique
    }

    If ($PsBoundParameters.ExcludeVuln) {
        $ExcludeVuln = $PsBoundParameters.ExcludeVuln | Sort-Object -Unique
    }

    # Get PowerShell Version
    $PowerShellVersion = $PsVersionTable.PSVersion

    # Get PowerShell version and OS platform (Linux or Windows).  If unsupported detected, fail out.
    Try {
        If ($PowerShellVersion -ge [Version]"7.0") {
            If ($PowerShellVersion -ge [Version]"7.2") {
                $PSStyle.Progress.View = "Classic"
                $PSStyle.OutputRendering = [System.Management.Automation.OutputRendering]::PlainText;
            }
            If ($IsLinux -eq $true) {
                $OSPlatform = "Linux"
            }
            If ($IsWindows -eq $true) {
                $OSPlatform = "Windows"
                [Version]$WMFVersion = (PowerShell.exe -Command {$PsVersionTable}).PsVersion
                If ($WMFVersion -lt [Version]"5.1") {
                    Throw "Windows Management Framework (WMF) $($WMFVersion -join '.') detected.  WMF 5.1 or greater is required."
                }
            }
        }
        ElseIf ($PowerShellVersion -lt [Version]"5.1" -or ($PowerShellVersion -join ".") -like "6.*") {
            Throw "PowerShell $($PowerShellVersion -join '.') detected.  Evaluate-STIG only supports PowerShell 5.1 or PowerShell 7.x and greater.  PowerShell 6.x is not supported."
        }
        Else {
            $OSPlatform = "Windows"
        }
    }
    Catch {
        Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
        Return
    }

    # Validate AFPath
    If ($AFPath) {
        Try {
            If (-Not($AFPath | Test-Path)) {
                Throw "-AFPath either does not exist or is not accessible."
            }
            ElseIf (($AFPath | Test-Path) -and (-Not($AFPath | Test-Path -PathType 'Container' -ErrorAction SilentlyContinue))) {
                Throw "-AFPath must point to a directory."
            }
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Return
        }
    }

    # Validate OutputPath
    If ($OutputPath) {
        Try {
            If (-Not($OutputPath | Test-Path)) {
            Throw "-OutputPath either does not exist or is not accessible."
            }
            ElseIf (($OutputPath | Test-Path) -and (-Not($OutputPath | Test-Path -PathType 'Container' -ErrorAction SilentlyContinue))) {
                Throw "-OutputPath must point to a directory."
            }
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Return
        }
    }

    If (Test-Path (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath "Master_Functions")){
        Try {
            # Import required modules
            If ($PowerShellVersion -lt [Version]"7.0") {
                Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath "Master_Functions") -ErrorAction Stop
            }
            Else {
                Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath "Master_Functions") -SkipEditionCheck -ErrorAction Stop
            }
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Exit 1
        }
    }
    Else{
        Write-Host "ERROR: 'Master_Functions' module not found.  Unable to continue." -ForegroundColor Red -BackgroundColor Black
        Exit 3
    }

    # If -ListSupportedSTIGs specified, display list and exit.
    If ($ListSupportedProducts) {
        Try {
            $STIGList_xsd = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "Schema_STIGList.xsd"
            $XmlFile = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
            If (-Not(Test-Path $XmlFile)) {
                Throw "'$Xmlfile' file not found.  Please update with -Update option."
            }
            ElseIf (-Not(Test-Path $STIGList_xsd)) {
                Throw "'$STIGList_xsd' file not found.  Please update with -Update option."
            }
            ElseIf ((Test-XmlValidation -XmlFile $XmlFile -SchemaFile $STIGList_xsd) -ne $true) {
                Throw "'$Xmlfile' failed schema validation.  Please update with -Update option."
            }

            Return $(Get-SupportedProducts -ES_Path $PsScriptRoot)

            # Remove Evaluate-STIG modules from memory
            Get-Module | Where-Object Path -like "$($PsScriptRoot)*" | Remove-Module -Force

            Exit
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black

            # Remove Evaluate-STIG modules from memory
            Get-Module | Where-Object Path -Like "$($PsScriptRoot)*" | Remove-Module -Force

            Exit 1
        }
    }

    # If -ListApplicableProducts specified, display list and exit.
    If ($ListApplicableProducts) {
        Try {
            # Confirm we have an elevated session.
            Switch ($OSPlatform) {
                "Windows" {
                    If (-NOT([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator") -and !$AltCredential -and ($LinuxList.count -eq 0)) {
                        Throw "You must run this from an elevated PowerShell session."
                    }
                }
                "Linux" {
                    If ((id -u) -ne 0) {
                        Throw "You must run this from an elevated PowerShell session."
                    }
                }
            }

            $STIGList_xsd = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "Schema_STIGList.xsd"
            $XmlFile = Join-Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
            If (-Not(Test-Path $XmlFile)) {
                Throw "'$Xmlfile' file not found.  Please update with -Update option."
            }
            ElseIf (-Not(Test-Path $STIGList_xsd)) {
                Throw "'$STIGList_xsd' file not found.  Please update with -Update option."
            }
            ElseIf ((Test-XmlValidation -XmlFile $XmlFile -SchemaFile $STIGList_xsd) -ne $true) {
                Throw "'$Xmlfile' failed schema validation.  Please update with -Update option."
            }

            Return $(Get-ApplicableProducts -ES_Path $PsScriptRoot)

            # Remove Evaluate-STIG modules from memory
            Get-Module | Where-Object Path -Like "$($PsScriptRoot)*" | Remove-Module -Force

            Exit
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black

            # Remove Evaluate-STIG modules from memory
            Get-Module | Where-Object Path -Like "$($PsScriptRoot)*" | Remove-Module -Force

            Exit 1
        }
    }

    # If -Version specified, display its output.
    If ($Version) {
        Try {
            $Result = [PSCustomObject]@{
                Version           = $EvaluateStigVersion
                RunningPath       = $PSScriptRoot
            }
            Return $Result
            Exit
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Exit 1
        }
    }

    # If -Update specified, download the latest updates.
    If ($Update) {
        Try {
            If ($PSBoundParameters.Proxy) {
                $Proxy = $PSBoundParameters.Proxy
            }
            Switch -Wildcard (Get-FileUpdatesFromRepo -PS_Path $PsScriptRoot -Proxy $Proxy) {
                "Successfully updated*" {
                    Write-Host $_ -ForegroundColor Green
                }
                "*requires no updating." {
                    Write-Host $_ -ForegroundColor Cyan
                }
                default {
                    Throw $_
                }
            }

            # Remove Evaluate-STIG modules from memory
            Get-Module | Where-Object Path -Like "$($PsScriptRoot)*" | Remove-Module -Force

            Break
        }
        Catch {
            Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black

            # Remove Evaluate-STIG modules from memory
            Get-Module | Where-Object Path -Like "$($PsScriptRoot)*" | Remove-Module -Force

            Break
        }
    }

    # Set initial variables
    $Global:LogComponent = "Evaluate-STIG $($ESVersion)"

    # If -AFPath not specified, set default
    If (-Not($AFPath)) {
        $AFPath = (Join-Path -Path $PsScriptRoot -ChildPath "AnswerFiles")
    }
    # If -OutputPath not specified, set default
    If (-not($OutputPath)) {
        Switch ($OSPlatform) {
            "Windows" {
                $OutputPath = "$env:PUBLIC\Documents\STIG_Compliance"
                if (!(Test-Path $OutputPath)) {
                    $null = New-Item -Path $(Split-Path -Path $OutputPath -Parent) -Name $(Split-Path -Path $OutputPath -Leaf) -ItemType Directory
                }
            }
            "Linux" {
                $OutputPath = "/opt/STIG_Compliance"
                if (!(Test-Path $OutputPath)) {
                    sudo mkdir $OutputPath
                }
            }
        }
    }

    if ($host.privatedata) {
        Try {
            # Set Progress Bar Colors
            $host.privatedata.ProgressForegroundColor = "White"

            switch ($ScanType) {
                "Unclassified" { $host.privatedata.ProgressBackgroundColor = "DarkGreen" }
                "Classified" { $host.privatedata.ProgressBackgroundColor = "DarkRed" }
            }
        }
        Catch {
            # Do nothing
        }
    }

    If ($ComputerName) {
        #####################################################
        # Scan remote system
        #####################################################

        Try {
            If ($IsLinux) {
                Throw "Parameter -ComputerName is only supported on Windows systems."
            }

            # Get local host data
            $LocalHost = New-Object System.Collections.Generic.List[System.Object]
            $NewObj = [PSCustomObject]@{
                HostName    = ([Environment]::MachineName).ToUpper()
                IPv4Address = (Get-NetIPAddress).IPv4Address
            }
            $LocalHost.Add($NewObj)

            # If source machine is to be scanned, confirm PS is elevated or that -AltCredential is selected
            If (($ComputerName -contains "127.0.0.1") -or ($ComputerName -contains "::1") -or ($ComputerName -contains "localhost") -or ($ComputerName -match $LocalHost.HostName) -or ($LocalHost.IPv4Address | ForEach-Object {If ($_ -in $ComputerName) {Return $true}})) {
                If (-NOT(([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator") -or $AltCredential)) {
                    Throw "LOCALHOST to be included in scan.  You must run this from an elevated PowerShell session or use -AltCredential."
                }
            }

            # Build arguments hashtable
            $HashArguments = @{
                ComputerName      = $ComputerName
                ScanType          = $ScanType
                VulnTimeout       = $VulnTimeout
                AFPath            = $AFPath
                AnswerKey         = $AnswerKey
                OutputPath        = $OutputPath
                ESVersion         = $ESVersion
                LogComponent      = $LogComponent
                OSPlatform        = $OSPlatform
                ES_Path           = $PsScriptRoot
                PowerShellVersion = $PowerShellVersion
            }
            If ($GenerateOQE) {
                $HashArguments.Add("GenerateOQE", $true)
            }
            If ($NoPrevious) {
                $HashArguments.Add("NoPrevious", $true)
            }
            If ($ApplyTattoo) {
                $HashArguments.Add("ApplyTattoo", $true)
            }
            If ($SelectSTIG) {
                $HashArguments.Add("SelectSTIG", $SelectSTIG)
            }
            If ($SelectVuln) {
                $HashArguments.Add("SelectVuln", $SelectVuln)
            }
            If ($ExcludeSTIG) {
                $HashArguments.Add("ExcludeSTIG", $ExcludeSTIG)
            }
            If ($ExcludeVuln) {
                $HashArguments.Add("ExcludeVuln", $ExcludeVuln)
            }
            If ($AltCredential) {
                $HashArguments.Add("AltCredential", $true)
            }
            If ($ThrottleLimit) {
                $HashArguments.Add("ThrottleLimit", $ThrottleLimit)
            }

            Invoke-RemoteScan @HashArguments
        }
        Catch {
            Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
        }
    }
    Else {
        #####################################################
        # Scan local system
        #####################################################

        # OS dependent prerequiste checks
        Switch ($OSPlatform) {
            "Windows" {
                Try {
                    # Confirm we have an elevated session.
                    If (-NOT([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator") -and !$AltCredential -and ($LinuxList.count -eq 0)) {
                        Throw "You must run this from an elevated PowerShell session."
                    }

                    # Check Windows version.  Windows version 6.1 or greater required.
                    # https://docs.microsoft.com/en-us/windows/win32/sysinfo/operating-system-version
                    If ([Version](Get-CimInstance Win32_OperatingSystem).Version -lt "6.1") {
                        Throw "$((Get-CimInstance Win32_OperatingSystem).Version) is not supported.  Must be version 6.1 or greater.  Cannot continue."
                    }

                    # Confirm native PowerShell session
                    $OSArch = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment' -Name PROCESSOR_ARCHITECTURE).PROCESSOR_ARCHITECTURE
                    If ($OSArch -eq "AMD64") {
                        If ([IntPtr]::Size -ne "8") {
                            Throw "32-Bit PowerShell session detected.  Evaluate-STIG must be ran in 64-Bit PowerShell on 64-Bit systems."
                        }
                    }

                    # This section not really working as designed.  Commenting out for now.  Refer to issue #549.
                    # Confirm only one instance of Evaluate-STIG is running
                    <# If ((Get-CimInstance Win32_Process -Filter "(Name='powershell.exe' OR Name='pwsh.exe') AND CommandLine LIKE '%Evaluate-STIG.ps1%'").Count -gt 1) {
                        Throw "Evaluate-STIG is already running."
                    } #>
                }
                Catch {
                    Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
                    Return
                }
            }
            "Linux" {
                Try {
                    # Confirm we have an elevated session.
                    If ((id -u) -ne 0) {
                        Throw "You must run this from an elevated PowerShell session."
                    }
                }
                Catch {
                    Write-Host "$($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
                    Return
                }

                # Check for prerequisites
                Try {
                    $null = lshw -version /dev/null
                }
                Catch {
                    Write-Host "'lshw' is required to be installed." -ForegroundColor Red -BackgroundColor Black
                    Return
                }

                if ($ComputerName) {
                    Write-Host "Remote computer option supports Windows only." -ForegroundColor Red -BackgroundColor Black
                    Return
                }
            }
        }

        # Test OutputPath connectivity
        If (-Not(Test-Path $OutputPath)) {
            Write-Host "$OutputPath is not accessible by $([Environment]::Username) on $MachineName." -ForegroundColor Red
            Return
        }

        # Set variables
        Switch ($OSPlatform) {
            "Windows" {
                $Global:WorkingDir = "$env:windir\Temp\Evaluate-STIG"
                $DomainRole = (Get-CimInstance Win32_ComputerSystem).DomainRole
            }
            "Linux" {
                $Global:WorkingDir = "/tmp/Evaluate-STIG"
                $Release = Get-Content /etc/os-release
                If ($release | Select-String "Workstation") {
                    $DomainRole = 1
                }
                ElseIf ($release | Select-String "Server") {
                    $DomainRole = 3
                }
                Else {
                    $DomainRole = 1
                }
            }
        }
        $MachineName = ([Environment]::MachineName).ToUpper()
        if ($SelectVuln){
            $Global:ResultsPath = Join-Path -Path $OutputPath -ChildPath "_Partial_$MachineName"
        }
        else{
            $Global:ResultsPath = Join-Path -Path $OutputPath -ChildPath $MachineName
        }
        $StartTime = Get-Date
        $Date = Get-Date -Format yyyyMMdd
        Set-Variable -Name ScanStartDate -Value (Get-Date -Format "MM/dd/yyyy") -Scope global
        $Global:STIGLog = Join-Path -Path $WorkingDir -ChildPath "Evaluate-STIG.log"
        [int]$Global:TotalMainSteps = 2
        [int]$Global:CurrentMainStep = 1
        [int]$Global:ProgressId = 1
        $Global:ProgressActivity = "Evaluate-STIG (Version: $ESVersion | Scan Type: $ScanType | Answer Key: $AnswerKey)"

        # Create WorkingDir
        If (-Not(Test-Path $WorkingDir)) {
            $null = New-Item $WorkingDir -ItemType Directory
        }

        # ++++++++++++++++++++++ Begin processing ++++++++++++++++++++++
        Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Initializing and generating list of required STIGs"

        # Check if $ExcludeSTIG, $SelectSTIG, $SelectVuln, or $ExcludeVuln contain a comma and if so, split them.  Needs to be in an array.  Can happen when calling Evaluate-STIG from Powershell.exe -File
        If ($ExcludeSTIG -and $ExcludeSTIG -match ","){
            $ExcludeSTIG = $ExcludeSTIG -Split ","
        }
        If ($SelectSTIG -and $SelectSTIG -match ",") {
            $SelectSTIG = $SelectSTIG -Split ","
        }
        If ($SelectVuln -and $SelectVuln -match ",") {
            $SelectVuln = $SelectVuln -Split ","
        }
        If ($ExcludeVuln -and $ExcludeVuln -match ",") {
            $ExcludeVuln = $ExcludeVuln -Split ","
        }

        If (Test-Path $STIGLog) {
            Remove-Item $STIGLog -Force
        }

        Write-Log $STIGLog "==========[Begin Local Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Executing: $($MyInvocation.Line)" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform

        # Verify Evaluate-STIG files integrity
        $Verified = $true
        Write-Log $STIGLog "Verifying Evaluate-STIG file integrity..." $LogComponent "Info" -OSPlatform $OSPlatform
        If (Test-Path (Join-Path -Path $PSScriptRoot -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")) {
            [XML]$FileListXML = Get-Content -Path (Join-Path -Path $PSScriptRoot -ChildPath "xml" | Join-Path -ChildPath "FileList.xml")
            If ((Test-XmlSignature -checkxml $FileListXML -Force) -ne $true) {
                Write-Log $STIGLog "'FileList.xml' failed authenticity check.  Unable to verify content integrity." $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Host "ERROR: 'FileList.xml' failed authenticity check.  Unable to verify content integrity." -ForegroundColor Red
                ForEach ($File in $FileListXML.FileList.File) {
                    If ($File.ScanReq -eq "Required") {
                        Write-Log $STIGLog "'$($File.Name)' is a required file but not found.  Scan results may be incomplete." $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Host "'$($File.Name)' is a required file but not found.  Scan results may be incomplete." -ForegroundColor Red
                    }
                }
            }
            Else {
                ForEach ($File in $FileListXML.FileList.File) {
                    $Path = (Join-Path -Path $PsScriptRoot -ChildPath $File.Path | Join-Path -ChildPath $File.Name)
                    If (Test-Path $Path) {
                        If ((Get-FileHash -Path $Path -Algorithm SHA256).Hash -ne $File.SHA256Hash) {
                            $Verified = $false
                            Write-Log $STIGLog "'$($Path)' failed integrity check." $LogComponent "Warning" -OSPlatform $OSPlatform
                        }
                    }
                    Else {
                        If ($File.ScanReq -eq "Required") {
                            $Verified = $false
                            Write-Log $STIGLog "'$($File.Name)' is a required file but not found.  Scan results may be incomplete." $LogComponent "Error" -OSPlatform $OSPlatform
                            Write-Host "'$($File.Name)' is a required file but not found.  Scan results may be incomplete." -ForegroundColor Red
                        }
                    }
                }
                If ($Verified -eq $true) {
                    Write-Log $STIGLog "Evaluate-STIG file integrity check passed." $LogComponent "Info" -OSPlatform $OSPlatform
                }
                Else {
                    Write-Host "WARNING: One or more Evaluate-STIG files failed integrity check." -ForegroundColor Yellow
                }
            }
        }
        Else {
            Write-Log $STIGLog "'FileList.xml' not found.  Cannot continue." $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: 'FileList.xml' not found.  Cannot continue." -ForegroundColor Red -BackgroundColor Black
            Exit 2
        }

        # Validate STIGList.xml and answer file for proper schema usage.
        $STIGList_xsd = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "Schema_STIGList.xsd"
        $AnswerFile_xsd = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "Schema_AnswerFile.xsd"

        # STIGList.xml validation
        $XmlFile = Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml"
        If (-Not(Test-Path $XmlFile)) {
            Write-Log $STIGLog "ERROR: '$XmlFile' - file not found.  Cannot continue." $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: '$XmlFile' - file not found.  Cannot continue." -ForegroundColor Red -BackgroundColor Black
            Exit 10010001
        }
        ElseIf (-Not(Test-Path $STIGList_xsd)) {
            Write-Log $STIGLog "ERROR: '$STIGList_xsd' - file not found.  Cannot continue." $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: '$STIGList_xsd' - file not found.  Cannot continue." -ForegroundColor Red -BackgroundColor Black
            Exit 10010001
        }
        ElseIf (-Not(Test-Path $AnswerFile_xsd)) {
            Write-Log $STIGLog "ERROR: '$AnswerFile_xsd' - file not found.  Cannot continue." $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: '$AnswerFile_xsd' - file not found.  Cannot continue." -ForegroundColor Red -BackgroundColor Black
            Exit 10010001
        }

        $Result = Test-XmlValidation -XmlFile $XmlFile -SchemaFile $STIGList_xsd
        If ($Result -ne $true) {
            Write-Log $STIGLog "ERROR: '$($XmlFile)' failed XML validation:" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: '$($XmlFile)' failed XML validation:" -ForegroundColor Red -BackgroundColor Black
            ForEach ($Item in $Result.Message) {
                Write-Log $STIGLog $Item $LogComponent "Warning" -OSPlatform $OSPlatform
                Write-Host $Item -ForegroundColor Yellow
            }
            Exit 10010001
        }

        Write-Log $STIGLog "Evaluate-STIG Version: $ESVersion" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Launching User: $([Environment]::Username)" $LogComponent "Info" -OSPlatform $OSPlatform

        # Pre-checks passed.  Begin processing.
        $EvalStart = Get-Date

        # Test connectivity to OutputPath and create folder for computer
        Try {
            If (-Not(Test-Path $ResultsPath)) {
                $null = New-Item $ResultsPath -ItemType Directory -ErrorAction Stop
                Start-Sleep 5
            }
        }
        Catch {
            Write-Log $STIGLog "Failed to create output path $ResultsPath)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Exit 10010001
        }

        # Write configuration data to log
        Write-Log $STIGLog "Hostname: $env:COMPUTERNAME" $LogComponent "Info" -OSPlatform $OSPlatform
        Switch ($DomainRole) {
            0 {
                Write-Log $STIGLog "Domain Role: Standalone Workstation" $LogComponent "Info" -OSPlatform $OSPlatform
            } # Standalone Workstation (0)
            1 {
                Write-Log $STIGLog "Domain Role: Member Workstation" $LogComponent "Info" -OSPlatform $OSPlatform
            } # Member Workstation (1)
            2 {
                Write-Log $STIGLog "Domain Role: Standalone Server" $LogComponent "Info" -OSPlatform $OSPlatform
            } # Standalone Server (2)
            3 {
                Write-Log $STIGLog "Domain Role: Member Server" $LogComponent "Info" -OSPlatform $OSPlatform
            } # Member Server (3)
            4 {
                Write-Log $STIGLog "Domain Role: Backup Domain Controller" $LogComponent "Info" -OSPlatform $OSPlatform
            } # Backup DC (4)
            5 {
                Write-Log $STIGLog "Domain Role: Primary Domain Controller" $LogComponent "Info" -OSPlatform $OSPlatform
            } # Primary DC (4)
            Default {
                Write-Log $STIGLog "Domain Role: Unknown" $LogComponent "Info" -OSPlatform $OSPlatform
            }
        }
        Write-Log $STIGLog "OS Platform: $OSPlatform" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "PS Version: $PowerShellVersion" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Scan Type: $ScanType" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Answer Key: $AnswerKey" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Answer File Path: $AFPath" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Results Path: $ResultsPath" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform

        # --- Begin Answer File validation
        Write-Log $STIGLog "Validating answer files..." $LogComponent "Info" -OSPlatform $OSPlatform
        $AnswerFileList = New-Object System.Collections.Generic.List[System.Object]
        $XmlFiles = Get-ChildItem -Path $AFPath | Where-Object Extension -eq ".xml"

        # Create temporary old schema file to look for answer files formatted for pre Evaluate-STIG 1.2107.0
        $OldSchemaFile = (Join-Path -Path $WorkingDir -ChildPath "ES_OldSchema.xsd")
        $OldSchema = '<xs:schema attributeFormDefault="unqualified" elementFormDefault="qualified" xmlns:xs="http://www.w3.org/2001/XMLSchema">' | Out-String
        $OldSchema += '  <xs:element name="STIGComments">' | Out-String
        $OldSchema += '    <xs:complexType>' | Out-String
        $OldSchema += '      <xs:sequence>' | Out-String
        $OldSchema += '        <xs:element name="Vuln" maxOccurs="unbounded" minOccurs="0">' | Out-String
        $OldSchema += '          <xs:complexType>' | Out-String
        $OldSchema += '            <xs:sequence>' | Out-String
        $OldSchema += '              <xs:element name="AnswerKey"  maxOccurs="unbounded" minOccurs="1">' | Out-String
        $OldSchema += '                <xs:complexType>' | Out-String
        $OldSchema += '                  <xs:sequence>' | Out-String
        $OldSchema += '                    <xs:element type="xs:string" name="ApprovedComment" maxOccurs="1" minOccurs="1"/>' | Out-String
        $OldSchema += '                    <xs:element name="ExpectedStatus">' | Out-String
        $OldSchema += '                      <xs:simpleType>' | Out-String
        $OldSchema += '                        <xs:restriction base="xs:string">' | Out-String
        $OldSchema += '                          <xs:enumeration value="Not_Reviewed"/>' | Out-String
        $OldSchema += '                          <xs:enumeration value="Open"/>' | Out-String
        $OldSchema += '                          <xs:enumeration value="NotAFinding"/>' | Out-String
        $OldSchema += '                          <xs:enumeration value="Not_Applicable"/>' | Out-String
        $OldSchema += '                        </xs:restriction>' | Out-String
        $OldSchema += '                      </xs:simpleType>' | Out-String
        $OldSchema += '                    </xs:element>' | Out-String
        $OldSchema += '                    <xs:element name="FinalStatus">' | Out-String
        $OldSchema += '                      <xs:simpleType>' | Out-String
        $OldSchema += '                        <xs:restriction base="xs:string">' | Out-String
        $OldSchema += '                          <xs:enumeration value="Not_Reviewed"/>' | Out-String
        $OldSchema += '                          <xs:enumeration value="Open"/>' | Out-String
        $OldSchema += '                          <xs:enumeration value="NotAFinding"/>' | Out-String
        $OldSchema += '                          <xs:enumeration value="Not_Applicable"/>' | Out-String
        $OldSchema += '                        </xs:restriction>' | Out-String
        $OldSchema += '                      </xs:simpleType>' | Out-String
        $OldSchema += '                    </xs:element>' | Out-String
        $OldSchema += '                    <xs:element type="xs:string" name="ValidationCode"/>' | Out-String
        $OldSchema += '                  </xs:sequence>' | Out-String
        $OldSchema += '                  <xs:attribute type="xs:string" name="Name" use="required"/>' | Out-String
        $OldSchema += '                </xs:complexType>' | Out-String
        $OldSchema += '              </xs:element>' | Out-String
        $OldSchema += '            </xs:sequence>' | Out-String
        $OldSchema += '            <xs:attribute type="xs:string" name="ID" use="required"/>' | Out-String
        $OldSchema += '          </xs:complexType>' | Out-String
        $OldSchema += '          <xs:unique name="AnswerKeyUniqueKey">' | Out-String
        $OldSchema += '            <xs:selector xpath="AnswerKey"/>' | Out-String
        $OldSchema += '            <xs:field xpath="@Name"/>' | Out-String
        $OldSchema += '          </xs:unique>' | Out-String
        $OldSchema += '        </xs:element>' | Out-String
        $OldSchema += '      </xs:sequence>' | Out-String
        $OldSchema += '      <xs:attribute type="xs:string" name="Name" use="required"/>' | Out-String
        $OldSchema += '    </xs:complexType>' | Out-String
        $OldSchema += '    <xs:unique name="VulnIdUniqueKey">' | Out-String
        $OldSchema += '      <xs:selector xpath="Vuln"/>' | Out-String
        $OldSchema += '      <xs:field xpath="@ID"/>' | Out-String
        $OldSchema += '    </xs:unique>' | Out-String
        $OldSchema += '  </xs:element>' | Out-String
        $OldSchema += '</xs:schema>' | Out-String
        $OldSchema | Out-File $OldSchemaFile -Force

        # Verify answer files for proper format...
        ForEach ($Item in $XmlFiles) {
            $Validation = (Test-XmlValidation -XmlFile $Item.FullName -SchemaFile $AnswerFile_xsd)
            If ($Validation -eq $true) {
                Write-Log $STIGLog "$($Item.Name) : Passed" $LogComponent "Info" -OSPlatform $OSPlatform
                [XML]$Content = Get-Content $Item.FullName
                If ($Content.STIGComments.Name) {
                    $NewObj = [PSCustomObject]@{
                        STIG       = $Content.STIGComments.Name
                        AnswerFile = $Item.Name
                        LastWriteTime  = $Item.LastWriteTime
                    }
                    $AnswerFileList.Add($NewObj)
                }
            }
            ElseIf ((Test-XmlValidation -XmlFile $Item.FullName -SchemaFile $OldSchemaFile) -eq $true) {
                Write-Log $STIGLog "$($Item.Name) : Warning - Answer file is for an older version of Evaluate-STIG and will be ignored.  Please update to new schema." $LogComponent "Warning" -OSPlatform $OSPlatform
                Write-Host "WARNING: $($Item.FullName) is for an older version of Evaluate-STIG and will be ignored.  Please update to new schema." -ForegroundColor Yellow
            }
            Else {
                Write-Log $STIGLog "$($Item.Name) : Error - Answer file failed schema validation and will be ignored.  Please correct or remove." $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Log $STIGLog "$($Validation.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Host "ERROR: '$($Item.FullName) failed schema validation and will be ignored.  Please correct or remove." -ForegroundColor Red
                Write-Host "$($Validation.Message)" -ForegroundColor Red
                Write-Host ""
            }
        }

        $AnswerFileList = $AnswerFileList | Sort-Object LastWriteTime -Descending
        Remove-Item $OldSchemaFile -Force
        Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
        # --- End Answer File validation

        # Build list of required STIGs
        Write-Log $STIGLog "Gathering list of STIGs applicable to this sytem..." $LogComponent "Info" -OSPlatform $OSPlatform
        Try {
            [XML]$STIGList = Get-Content (Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath "STIGList.xml")
            $STIGsToProcess = New-Object System.Collections.Generic.List[System.Object]
            If ($SelectSTIG) {
                ForEach ($Node in $STIGList.List.ChildNodes) {
                    If ($Node.Shortname -in $SelectSTIG) {
                        If ($Node.DetectionCode -and (Invoke-Expression $Node.DetectionCode) -eq $true) {
                            If ($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)}) {
                                $AFtoUse = (($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)})[0]).AnswerFile
                            }
                            Else {
                                $AFtoUse = ""
                            }
                            $NewObj = [PSCustomObject]@{
                                Name           = $Node.Name
                                Shortname      = $Node.ShortName
                                Template       = $Node.Template
                                AnswerFile     = $AFtoUse
                                PsModule       = $Node.PsModule
                                PsModuleVer    = $Node.PsModuleVer
                                Classification = $Node.Classification
                            }
                            $STIGsToProcess.Add($NewObj)
                        }
                        Else {
                            Write-Log $STIGLog "Scan for '$($Node.Name)' requested with -SelectSTIG but is not applicable to this system so will be ignored." $LogComponent "Warning" -OSPlatform $OSPlatform
                            Write-Host "WARNING: Scan for '$($Node.Name)' requested with -SelectSTIG but is not applicable to this system so will be ignored." -ForegroundColor Yellow
                        }
                    }
                }
            }
            Else {
                ForEach ($Node in $STIGList.List.ChildNodes) {
                    If ($Node.DetectionCode -and (Invoke-Expression $Node.DetectionCode) -eq $true) {
                        If ($Node.Shortname -in $ExcludeSTIG) {
                            Write-Log $STIGLog "'$($Node.Name)' is applicable to this system but has been excluded from scan with the -ExcludeSTIG option." $LogComponent "Warning" -OSPlatform $OSPlatform
                        }
                        Else {
                            If ($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)}) {
                                $AFtoUse = (($AnswerFileList | Where-Object {($_.STIG -eq $Node.ShortName -or $_.STIG -eq $Node.Name)})[0]).AnswerFile
                            }
                            Else {
                                $AFtoUse = ""
                            }
                            $NewObj = [PSCustomObject]@{
                                Name           = $Node.Name
                                Shortname      = $Node.ShortName
                                Template       = $Node.Template
                                AnswerFile     = $AFtoUse
                                PsModule       = $Node.PsModule
                                PsModuleVer    = $Node.PsModuleVer
                                Classification = $Node.Classification
                            }
                            $STIGsToProcess.Add($NewObj)
                        }
                    }
                }
            }
            [int]$TotalMainSteps = $TotalMainSteps + $STIGsToProcess.Count
        }
        Catch {
            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Exit 10010001
        }

        # Write list of STIGs that will be evaluated to log
        Write-Log $STIGLog "The following STIGs will be evaluated:" $LogComponent "Info" -OSPlatform $OSPlatform
        ForEach ($STIG in $STIGsToProcess) {
            Write-Log $STIGLog "STIG: $($STIG.Name)  |  AnswerFile: $($STIG.AnswerFile)" $LogComponent "Info" -OSPlatform $OSPlatform
        }
        Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform

        # Confirm STIG specific prerequisites are met
        If (($STIGsToProcess.Name -like "Microsoft SQL Server*") -or ($STIGsToProcess.Name -like "IIS *")) {
            $AvailModules = (Get-Module -ListAvailable -All).Name
            # IIS
            If ($STIGsToProcess.Name -like "IIS *") {
                If ("WebAdministration" -notin $AvailModules) {
                    Write-Log $STIGLog "'WebAdministration' module is not available to PowerShell." $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Log $STIGLog "IIS checklists will not be generated." $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Host "ERROR: 'WebAdministration' module is not available to PowerShell. IIS checklists will not be generated." -ForegroundColor Red
                    $STIGsToIgnore = $STIGsToProcess | Where-Object Name -like "IIS *"
                    ForEach ($Obj in $STIGsToIgnore) {
                        [Void]$STIGsToProcess.Remove($Obj)
                    }
                }
            }

            # SQL Server
            If ($STIGsToProcess.Name -like "Microsoft SQL Server*") {
                If ("SqlServer" -notin $AvailModules) {
                    Write-Log $STIGLog "'SqlServer' module is not available to PowerShell." $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Log $STIGLog "SQL checklists will not be generated." $LogComponent "Error" -OSPlatform $OSPlatform
                    Write-Host "ERROR: 'SqlServer' module is not available to PowerShell. SQL checklists will not be generated." -ForegroundColor Red
                    $STIGsToIgnore = $STIGsToProcess | Where-Object Name -like "Microsoft SQL Server*"
                    ForEach ($Obj in $STIGsToIgnore) {
                        [Void]$STIGsToProcess.Remove($Obj)
                    }
                }
            }
            Remove-Variable AvailModules
        }

        # If no supported STIGs are applicable, log it and continue
        If ($STIGsToProcess.count -eq 0) {
            Write-Log $STIGLog "No Evaluate-STIG supported STIGs are applicable to this system." $LogComponent "Warning" -OSPlatform $OSPlatform
            Write-Host "No Evaluate-STIG supported STIGs are applicable to this system." -ForegroundColor Yellow
        }
        Else {
            Write-Log $STIGLog "Applicable STIGs to process - $($STIGsToProcess.count)" $LogComponent "Info" -OSPlatform $OSPlatform
            Write-Host "Applicable STIGs to process - $($STIGsToProcess.count)" -ForegroundColor Magenta
        }

        # Remove orphaned objects
        Write-Log $STIGLog "Checking for and removing orphaned objects from a previous scan..." $LogComponent "Info" -OSPlatform $OSPlatform
        Try {
            $TempFiles = Get-Item -Path $WorkingDir\* -Exclude Evaluate-STIG.log
            If ($TempFiles) {
                ForEach ($Item in $TempFiles) {
                    Write-Log $STIGLog "Removed orphaned object: $($Item.FullName)" $LogComponent "Info" -OSPlatform $OSPlatform
                    $null = Remove-Item -Path $Item.FullName -Recurse -ErrorAction Stop
                }
            }
            Switch ($OSPlatform) {
                "Windows" {
                    # Remove existing Evaluate-STIG_UserHive in case it exists
                    If (Test-Path -Path Registry::HKLM\SOFTWARE\Evaluate-STIG_UserHive) {
                        $null = Remove-Item -Path Registry::HKLM\SOFTWARE\Evaluate-STIG_UserHive -Recurse -Force -ErrorAction Stop
                        Write-Log $STIGLog "Removed orphaned object: HKLM:SOFTWARE\Evaluate-STIG_UserHive" $LogComponent "Info" -OSPlatform $OSPlatform
                    }
                }
                "Linux" {
                    # TBD
                }
            }
        }
        Catch {
            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Exit 10010001
        }

        If ($GenerateOQE) {
            $TotalMainSteps = $TotalMainSteps + 1
        }

        # OS dependent steps
        If ($OSPlatform -eq "Windows") {
            $TotalMainSteps = $TotalMainSteps + 1
            $ExtFilesRequired = $false
            ForEach ($Item in $STIGsToProcess.ShortName) {
                If ($Item -in @("DotNET4", "Win10", "Win11", "WinServer2008R2MS", "WinServer2008R2DC", "WinServer2012DC", "WinServer2012MS", "WinServer2016", "WinServer2019", "WinServer2022")) {
                    $ExtFilesRequired = $true
                }
            }
            If ($ExtFilesRequired -eq $true) {
                $TotalMainSteps = $TotalMainSteps + 1
            }

            # =========== Determine User to Evaluate ===========
            If ($STIGsToProcess.count -gt 0) {
                Write-Log $STIGLog "Determining which user to evaluate for HKCU items" $LogComponent "Info" -OSPlatform $OSPlatform
                Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Determining user to evaluate and importing registry hive" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
                $CurrentMainStep++

                # Get all profile paths and find which ntuser.pol was most recently updated.
                $UserToProcess = Get-UsersToEval -ProvideSingleUser
                If ($UserToProcess) {
                    Write-Log $STIGLog "Will evaluate $($UserToProcess.Username) for user-based settings..." $LogComponent "Info" -OSPlatform $OSPlatform
                    Write-Log $STIGLog "    SID: $($UserToProcess.SID)" $LogComponent "Info" -OSPlatform $OSPlatform
                    If ($UserToProcess.LastPolicyUpdate -eq "Never") {
                        Write-Log $STIGLog "    Policy Updated: $($UserToProcess.LastPolicyUpdate)" $LogComponent "Info" -OSPlatform $OSPlatform
                    }
                    Else {
                        Write-Log $STIGLog "    Policy Updated: $($UserToProcess.LastPolicyUpdate) ($((New-TimeSpan -Start $UserToProcess.LastPolicyUpdate -End (Get-Date)).Days) days ago)" $LogComponent "Info" -OSPlatform $OSPlatform
                    }
                    Write-Log $STIGLog "    Last Used: $($UserToProcess.LastUseTime)" $LogComponent "Info" -OSPlatform $OSPlatform
                    Write-Log $STIGLog "    Profile Path: $($UserToProcess.LocalPath)" $LogComponent "Info" -OSPlatform $OSPlatform
                }
                Else {
                    Write-Log $STIGLog "No scannable user profile found.  Will evaluate .DEFAULT profile for user-based settings" $LogComponent "Warning" -OSPlatform $OSPlatform
                    $UserToProcess = @{ }
                    $UserToProcess.UserName = ".DEFAULT"
                    $UserToProcess.SID = ".DEFAULT"
                }

                # =========== Export and Load User Registry Hive ===========
                # If SID is not listed in HKEY_USERS, user is not currently logged on and we must load the hive from NTUSER.dat
                $RegLoadRequired = $false
                If (-Not(Test-Path -Path Registry::HKU\$($UserToProcess.SID))) {
                    $RegLoadRequired = $true
                    Write-Log $STIGLog "User is not currently logged on.  Loading NTUSER.dat to HKU:\$($UserToProcess.SID)" $LogComponent "Info" -OSPlatform $OSPlatform
                    $NTUSER_DAT = [Char]34 + "$($UserToProcess.LocalPath)\NTUSER.DAT" + [Char]34
                    Start-Process -FilePath REG.exe -ArgumentList "LOAD HKU\$($UserToProcess.SID) $($NTUSER_DAT)" -Wait -WindowStyle Hidden
                }

                # Export the user's hive and then temporarily import it to HKLM\SOFTWARE\Evaluate-STIG_UserHive.  In the event that the user logs off while the script is executing, we still have access to the user's registry data for checks.
                $UserHive_UnmodifiedName = "Evaluate-STIG_UserHive_Original.reg"
                $StreamWriter = [IO.File]::CreateText("$WorkingDir\Evaluate-STIG_UserHive.reg")
                Write-Log $STIGLog "Creating temporary copy of user's registry hive to HKLM:\SOFTWARE\Evaluate-STIG_UserHive" $LogComponent "Info" -OSPlatform $OSPlatform
                Start-Process -FilePath REG.exe -ArgumentList "EXPORT HKU\$($UserToProcess.SID) $($WorkingDir)\$($UserHive_UnmodifiedName) /y" -Wait -WindowStyle Hidden
                Switch -File "$WorkingDir\$UserHive_UnmodifiedName" {
                    Default {
                        # In effort to properly import "defaultformat" registry value for MS Word, replace line "defaultformat"=" with "defaultformat"="" and remove the follow on whitespace line
                        $StreamWriter.Write($_.Replace("[HKEY_USERS", "[HKEY_LOCAL_MACHINE\SOFTWARE\Evaluate-STIG_UserHive").Replace('"defaultformat"="', '"defaultformat"=""').Replace('              "', '') + "`r`n")
                    }
                }
                $StreamWriter.Close()
                Start-Process -FilePath REG.exe -ArgumentList "IMPORT $($WorkingDir)\Evaluate-STIG_UserHive.reg" -Wait -WindowStyle Hidden

                # If we had to load the NTUSER.dat into the registry, we unload it here.
                If ($RegLoadRequired -eq $true) {
                    [System.GC]::Collect() # garbage collection to help unload the hive
                    Write-Log $STIGLog "Unloading hive HKU:\$($UserToProcess.SID)" $LogComponent "Info" -OSPlatform $OSPlatform
                    Start-Process -FilePath REG.exe -ArgumentList "UNLOAD HKU\$($UserToProcess.SID)" -Wait -WindowStyle Hidden
                }
            }
            Else {
                # Set UserName and SID to "NA"
                $UserToProcess = @{
                    UserName = "NA"
                    SID      = "NA"
                }
            }

            # =========== Create External Reference Files ===========
            If ($ExtFilesRequired -eq $true) {
                Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Creating temporary export files for enumeration" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
                $CurrentMainStep++

                # AppLocker
                ForEach ($Item in $STIGsToProcess.ShortName) {
                    If ($Item -in @("Win10", "Win11", "WinServer2008R2MS", "WinServer2008R2DC", "WinServer2012DC", "WinServer2012MS", "WinServer2016", "WinServer2019", "WinServer2022")) {
                        $AppLockerRequired = $true
                    }
                }
                If ($AppLockerRequired -eq $true) {
                    Try {
                        Write-Log $STIGLog "Collecting AppLocker effective policy and saving to $($WorkingDir)\$($AppLockerPolFile)" $LogComponent "Info" -OSPlatform $OSPlatform
                        $AppLockerPolFile = "AppLockerPol_$(${env:computername})_$($Date).xml"
                        If (($PsVersionTable.PSVersion -join ".") -lt [Version]"7.0") {
                            Import-Module AppLocker
                        }
                        Else {
                            Import-Module AppLocker -SkipEditionCheck
                        }
                        Get-AppLockerPolicy -Effective -Xml -ErrorAction Stop | Out-File $WorkingDir\$($AppLockerPolFile) -Force
                    }
                    Catch {
                        $AppLockerRequired = $false
                        Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    }
                }

                # Security Policy
                ForEach ($Item in $STIGsToProcess.ShortName) {
                    If ($Item -in @("Win10", "Win11", "WinServer2008R2MS", "WinServer2008R2DC", "WinServer2012DC", "WinServer2012MS", "WinServer2016", "WinServer2019", "WinServer2022")) {
                        $SecPolRequired = $true
                    }
                }
                If ($SecPolRequired -eq $true) {
                    Try {
                        Write-Log $STIGLog "Exporting security policy" $LogComponent "Info" -OSPlatform $OSPlatform
                        $SecPolFileName = "Evaluate-STIG_SecPol.ini"
                        Start-Process -FilePath secedit.exe -ArgumentList "/export /cfg $($WorkingDir)\$($SecPolFileName)" -Wait -WindowStyle Hidden
                    }
                    Catch {
                        Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
                        Exit 10010001
                    }
                }

                # List of .exe.config files
                $ConfigFileListRequired = $false
                ForEach ($Item in $STIGsToProcess.ShortName) {
                    If ($Item -in @("DotNET4")) {
                        $ConfigFileListRequired = $true
                    }
                }
                If ($ConfigFileListRequired -eq $true) {
                    Try {
                        Write-Log $STIGLog "Collecting list of machine.config and *.exe.config files for .NET Framework 4 STIG to $($WorkingDir)\Evaluate-STIG_Net4FileList.txt" $LogComponent "Info" -OSPlatform $OSPlatform

                        # Get .Net 4 Framework machine.config files
                        $frameworkMachineConfig = "$env:SYSTEMROOT\Microsoft.NET\Framework\v4.0.30319\Config\machine.config"
                        $framework64MachineConfig = "$env:SYSTEMROOT\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config"

                        # Get hard disk drive letters
                        $driveLetters = (Get-CimInstance Win32_LogicalDisk | Where-Object DriveType -eq 3)

                        # Get configuration files
                        $allConfigFiles = @()
                        $allConfigFiles += Get-ChildItem $frameworkMachineConfig
                        $allConfigFiles += Get-ChildItem $framework64MachineConfig
                        $allConfigFiles += (ForEach-Object -InputObject $driveLetters { Get-ChildItem ($_.DeviceID + "\") -Recurse -Filter *.exe.config -ErrorAction SilentlyContinue | Where-Object { ($_.FullName -NotLike "*Windows\CSC\*") -and ($_.FullName -NotLike "*Windows\WinSxS\*") } })
                        $allConfigFiles.FullName | Out-File $WorkingDir\Evaluate-STIG_Net4FileList.txt -Force
                    }
                    Catch {
                        $ConfigFileListRequired = $false
                        Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    }
                }
            }
        }
        Else {
            # Set UserName and SID to "NA"
            $UserToProcess = @{
                UserName = whoami
                SID      = "NA"
            }
        }

        # =========== Build Checklists ===========
        ForEach ($Item in $STIGsToProcess) {
            If ($Item.ShortName -like "IIS*") {
                Remove-Module WebAdministration -ErrorAction SilentlyContinue
                Import-Module WebAdministration -WarningAction SilentlyContinue
            }
            [System.GC]::Collect()

            Try {
                Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Evaluating STIG: $($Item.Name)" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
                Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                Write-Log $STIGLog "Begin processing: $($Item.Name)" $LogComponent "Info" -OSPlatform $OSPlatform
                $CurrentMainStep++

                $ModError = ""
                Try {
                    [XML]$CKLData = Get-Content -Path (Join-Path -Path $PsScriptRoot -ChildPath "CKLTemplates" | Join-Path -ChildPath $($Item.Template)) -ErrorAction Stop
                    [int]$TotalSubSteps = ($CKLData.CHECKLIST.STIGS.iSTIG.vuln).Count
                    [int]$CurrentSubStep = 1

                    Write-Log $STIGLog "Importing scan module: $($Item.PsModule)" $LogComponent "Info" -OSPlatform $OSPlatform
                    If ($PowerShellVersion -lt [Version]"7.0") {
                        Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath $($Item.PsModule)) -ErrorAction Stop
                    }
                    Else {
                        Import-Module (Join-Path -Path $PsScriptRoot -ChildPath "Modules" | Join-Path -ChildPath $($Item.PsModule)) -SkipEditionCheck -ErrorAction Stop
                    }
                    $PsModule = (Get-Module $Item.PsModule)
                    Write-Log $STIGLog "Module Version: $($PsModule.Version)" $LogComponent "Info" -OSPlatform $OSPlatform
                }
                Catch {
                    $ModError = $_.Exception.Message
                }

                If ($ModError) {
                    # If module failed to import, display reason, how to resolve, and continue to next STIG.
                    Write-Log $STIGLog "ERROR: $($ModError)" $LogComponent "Error" -OSPlatform $OSPlatform
                    Switch ($Item.Classification) {
                        {$_ -in @("UNCLASSIFIED")} {
                            Write-Log $STIGLog "Please run '.\Evaluate-STIG.ps1 -Update' to restore this module or download the 'Evaluate-STIG_$($EvaluateStigVersion).zip from one of these locations:" $LogComponent "Error" -OSPlatform $OSPlatform
                            Write-Log $STIGLog "(NIPR) https://spork.navsea.navy.mil/nswc-crane-division/evaluate-stig/-/releases" $LogComponent "Error" -OSPlatform $OSPlatform
                            Write-Log $STIGLog "(NIPR) https://intelshare.intelink.gov/sites/NAVSEA-RMF" $LogComponent "Error" -OSPlatform $OSPlatform
                            Write-Log $STIGLog "(SIPR) https://intelshare.intelink.sgov.gov/sites/NAVSEA-RMF" $LogComponent "Error" -OSPlatform $OSPlatform
                            Write-Host "ERROR: $($ModError)" -ForegroundColor Red
                            Write-Host "Please run '.\Evaluate-STIG.ps1 -Update' to restore this module or download the 'Evaluate-STIG_$($EvaluateStigVersion).zip from one of these locations:" -ForegroundColor Red
                            Write-Host "-  (NIPR) https://spork.navsea.navy.mil/nswc-crane-division/evaluate-stig/-/releases" -ForegroundColor Red
                            Write-Host "-  (NIPR) https://intelshare.intelink.gov/sites/NAVSEA-RMF" -ForegroundColor Red
                            Write-Host "-  (SIPR) https://intelshare.intelink.sgov.gov/sites/NAVSEA-RMF" -ForegroundColor Red
                        }
                        DEFAULT {
                            Write-Log $STIGLog "Please this download CUI add-on module from:" $LogComponent "Error" -OSPlatform $OSPlatform
                            Write-Log $STIGLog "(NIPR) https://intelshare.intelink.gov/sites/NAVSEA-RMF" $LogComponent "Error" -OSPlatform $OSPlatform
                            Write-Log $STIGLog "(SIPR) https://intelshare.intelink.sgov.gov/sites/NAVSEA-RMF" $LogComponent "Error" -OSPlatform $OSPlatform
                            Write-Host "ERROR: $($ModError)" -ForegroundColor Red
                            Write-Host "Please download this CUI add-on module from:" -ForegroundColor Red
                            Write-Host "-  (NIPR) https://intelshare.intelink.gov/sites/NAVSEA-RMF" -ForegroundColor Red
                            Write-Host "-  (SIPR) https://intelshare.intelink.sgov.gov/sites/NAVSEA-RMF" -ForegroundColor Red
                        }
                    }
                }
                Else {
                    # Generate Checklist
                    Write-Log $STIGLog "Generating checklist and saving to $ResultsPath" $LogComponent "Info" -OSPlatform $OSPlatform
                    If (-Not(Test-Path -Path (Join-Path -Path $ResultsPath -ChildPath "Checklist"))) {
                        $null = New-Item -Path $ResultsPath -Name "Checklist" -ItemType Directory
                    }

                    $HashArguments = @{
                        STIGName           = $($Item.Name)
                        ShortName          = $($Item.ShortName)
                        TemplateName       = $($Item.Template)
                        CklSourcePath      = $(Join-Path -Path $PsScriptRoot -ChildPath "CKLTemplates")
                        CklDestinationPath = $(Join-Path -Path $ResultsPath -ChildPath "Checklist")
                        ModulesPath        = $(Join-Path -Path $PsScriptRoot -ChildPath "Modules")
                        ScanType           = $($ScanType)
                        VulnTimeout        = $($VulnTimeout)
                        AnswerKey          = $($AnswerKey)
                        WorkingDir         = $($WorkingDir)
                        Username           = $($UserToProcess.Username)
                        UserSID            = $($UserToProcess.SID)
                        OSPlatform         = $($OSPlatform)
                        ProgressId         = $($ProgressId)
                        TotalSubSteps      = $($TotalSubSteps)
                        CurrentSubStep     = $($CurrentSubStep)
                    }
                    If ($PsModule) {
                        $HashArguments.Add("PsModule", $($PsModule))
                    }
                    If (($Item.AnswerFile) -and (Test-Path -Path (Join-Path -Path $AFPath -ChildPath $($Item.AnswerFile)))) {
                        $AnswerFileToPass = (Join-Path -Path $AFPath -ChildPath $($Item.AnswerFile))
                        $HashArguments.Add("AnswerFile", $($AnswerFileToPass))
                    }
                    If ($NoPrevious) {
                        $HashArguments.Add("NoPrevious", $true)
                    }
                    If ($SelectVuln) {
                        $HashArguments.Add("SelectVuln", $($SelectVuln))
                    }
                    If ($ExcludeVuln) {
                        $HashArguments.Add("ExcludeVuln", $($ExcludeVuln))
                    }

                    # Create ckl file(s)
                    Switch ($Item.Name) {
                        {$_ -eq "Apache 2.4 Site Windows" -or $_ -eq "Apache 2.4 Site Unix"} {
                            # Get all the instances of apache running and their relevant information.

                            $ApacheInstances = @(Get-ApacheSites)
                            $HashArguments.Add("ApacheInstance", $null)
                            $HashArguments.Add("WebOrDB", "Web")
                            $HashArguments.Add("VirtualHost", $null)
                            $HashArguments.Add("Site", "")

                            foreach ($instance in $ApacheInstances) {
                                $HashArguments.ApacheInstance = $instance
                                foreach ($vhost in $instance.VirtualHosts) {
                                    $HashArguments.VirtualHost = $vhost
                                    if ($vhost.Index -eq -1) {
                                        $HashArguments.Site = ("BaseConfig-" + $instance.Index)
                                    }
                                    Else {
                                        $HashArguments.Site = ($vhost.SiteName + "-" + $vhost.SitePort)
                                    }
                                    Write-Log $STIGLog "----------------Writing CKL------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                    Write-Ckl @HashArguments
                                }
                            }
                        }

                        {$_ -eq "Apache 2.4 Server Windows" -or $_ -eq "Apache 2.4 Server Unix"} {
                            # Get all the instances of apache running and their relevant information.

                            $ApacheInstances = @(Get-ApacheSites)
                            $HashArguments.Add("ApacheInstance", $null)
                            $HashArguments.Add("WebOrDB", "Web")
                            $HashArguments.Add("VirtualHost", $null)
                            $HashArguments.Add("Site", "")

                            foreach ($instance in $ApacheInstances) {
                                $HashArguments.ApacheInstance = $instance
                                $HashArguments.Site = ("Server-" + $instance.Index)
                                Write-Log $STIGLog "----------------Writing CKL------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                Write-Ckl @HashArguments
                            }
                        }
                        "Microsoft Office 365" {
                            $HashArguments.Add("InstalledO365Apps", $(Get-InstalledO365Apps))
                            Write-Ckl @HashArguments
                        }
                        "IIS 8.5 Site" {
                            $HashArguments.Add("WebOrDB", "Web")
                            $HashArguments.Add("Site", "")
                            # Run IIS Site STIG for each website
                            If (($PsVersionTable.PSVersion -join ".") -lt [Version]"6.0") {
                                $AllSites = Get-WebSite
                            }
                            Else {
                                $PSCommand = "PowerShell.exe -Command {Get-WebSite}"
                                $AllSites = Invoke-Expression $PSCommand
                            }
                            $i = 0
                            ForEach ($Site in $Allsites) {
                                $HashArguments.Site = "$($Site.Name)"
                                If ($i -gt 0) {
                                    Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                }
                                Write-Ckl @HashArguments
                                $i++
                            }
                        }
                        "IIS 10.0 Site" {
                            $HashArguments.Add("WebOrDB", "Web")
                            $HashArguments.Add("Site", "")
                            # Run IIS Site STIG for each website
                            If (($PsVersionTable.PSVersion -join ".") -lt [Version]"6.0") {
                                $AllSites = Get-WebSite
                            }
                            Else {
                                $PSCommand = "PowerShell.exe -Command {Get-WebSite}"
                                $AllSites = Invoke-Expression $PSCommand
                            }
                            $i = 0
                            ForEach ($Site in $Allsites) {
                                $HashArguments.Site = "$($Site.Name)"
                                If ($i -gt 0) {
                                    Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                }
                                Write-Ckl @HashArguments
                                $i++
                            }
                        }

                        "McAfee ENS 10x Local" {
                            $EnsConfig = Get-EnsConfig
                            $HashArguments.Add("EnsConfig", $EnsConfig)
                            Write-Log $STIGLog "----------------Writing CKL------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                            Write-Ckl @HashArguments
                        }

                        "Microsoft SQL Server 2016 Instance" {
                            $HashArguments.Add("WebOrDB", "DB")
                            $HashArguments.Add("Instance", "Instance")
                            $HashArguments.Add("Database", "master")
                            Import-Module -Name SQLServer -WarningAction SilentlyContinue
                            $allInstances = Get-AllInstances | Where-Object {[Version]$_.Version -ge "13.0"}
                            $i = 0
                            ForEach ($Instance in $allInstances) {
                                If ($Instance.Status -eq "Running") {
                                    If ((Get-InstanceVersion $Instance.Name) -ge 2016) {
                                        $HashArguments.Instance = "$($Instance.Name)"
                                        If ($i -gt 0) {
                                            Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                        }
                                        Write-Ckl @HashArguments
                                    }
                                }
                                Else {
                                    Write-Log $STIGLog "Unable to create CKL for SQL instance $($Instance.Name)" $LogComponent "Error" -OSPlatform $OSPlatform
                                    Write-Log $STIGLog "Service : $($Instance.Service)" $LogComponent "Error" -OSPlatform $OSPlatform
                                    Write-Log $STIGLog "Status : $($Instance.Status)" $LogComponent "Error" -OSPlatform $OSPlatform
                                }
                                $i++
                            }
                        }

                        "Microsoft SQL Server 2016 Database" {
                            $HashArguments.Add("WebOrDB", "DB")
                            $HashArguments.Add("Instance", "")
                            $HashArguments.Add("Database", "")
                            Import-Module -Name SQLServer -WarningAction SilentlyContinue
                            $allInstances = Get-AllInstances | Where-Object {[Version]$_.Version -ge "13.0"}
                            ForEach ($Instance in $allInstances) {
                                If ($Instance.Status -eq "Running") {
                                    If ((Get-InstanceVersion $Instance.Name) -ge 2016) {
                                        $HashArguments.Instance = "$($Instance.Name)"
                                        $allDatabases = (invoke-sqlcmd "select name from sys.databases where state = 0" -ServerInstance $Instance.Name).Name
                                        $i = 0
                                        ForEach ($Database in $allDatabases) {
                                            $HashArguments.Database = "$Database"
                                            If ($i -gt 0) {
                                                Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                            }
                                            Write-Ckl @HashArguments
                                            $i++
                                        }
                                    }
                                }
                                Else {
                                    Write-Log $STIGLog "Unable to create database CKLs for SQL instance $($Instance.Name)" $LogComponent "Error" -OSPlatform $OSPlatform
                                    Write-Log $STIGLog "Service : $($Instance.Service)" $LogComponent "Error" -OSPlatform $OSPlatform
                                    Write-Log $STIGLog "Status : $($Instance.Status)" $LogComponent "Error" -OSPlatform $OSPlatform
                                }
                            }
                        }

                        "Microsoft SQL Server 2014 Instance" {
                            $HashArguments.Add("WebOrDB", "DB")
                            $HashArguments.Add("Instance", "Instance")
                            $HashArguments.Add("Database", "master")
                            Import-Module -Name SQLServer -WarningAction SilentlyContinue
                            $allInstances = Get-AllInstances | Where-Object {[Version]$_.Version -like "12.*"}
                            $i = 0
                            ForEach ($Instance in $allInstances) {
                                If ($Instance.Status -eq "Running") {
                                    If ((Get-InstanceVersion $Instance.Name) -eq 2014) {
                                        $HashArguments.Instance = "$($Instance.Name)"
                                        If ($i -gt 0) {
                                            Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                        }
                                        Write-Ckl @HashArguments
                                    }
                                }
                                Else {
                                    Write-Log $STIGLog "Unable to create CKL for SQL instance $($Instance.Name)" $LogComponent "Error" -OSPlatform $OSPlatform
                                    Write-Log $STIGLog "Service : $($Instance.Service)" $LogComponent "Error" -OSPlatform $OSPlatform
                                    Write-Log $STIGLog "Status : $($Instance.Status)" $LogComponent "Error" -OSPlatform $OSPlatform
                                }
                                $i++
                            }
                        }

                        "Microsoft SQL Server 2014 Database" {
                            $HashArguments.Add("WebOrDB", "DB")
                            $HashArguments.Add("Instance", "")
                            $HashArguments.Add("Database", "")
                            Import-Module -Name SQLServer -WarningAction SilentlyContinue
                            $allInstances = Get-AllInstances | Where-Object {[Version]$_.Version -like "12.*"}
                            ForEach ($Instance in $allInstances) {
                                If ($Instance.Status -eq "Running") {
                                    If ((Get-InstanceVersion $Instance.Name) -eq 2014) {
                                        $HashArguments.Instance = "$($Instance.Name)"
                                        $allDatabases = (Invoke-Sqlcmd "select name from sys.databases where state = 0" -ServerInstance $Instance.Name).Name
                                        $i = 0
                                        ForEach ($Database in $allDatabases) {
                                            $HashArguments.Database = "$Database"
                                            If ($i -gt 0) {
                                                Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                            }
                                            Write-Ckl @HashArguments
                                            $i++
                                        }
                                    }
                                }
                                Else {
                                    Write-Log $STIGLog "Unable to create database CKLs for SQL instance $($Instance.Name)" $LogComponent "Error" -OSPlatform $OSPlatform
                                    Write-Log $STIGLog "Service : $($Instance.Service)" $LogComponent "Error" -OSPlatform $OSPlatform
                                    Write-Log $STIGLog "Status : $($Instance.Status)" $LogComponent "Error" -OSPlatform $OSPlatform
                                }
                            }
                        }

                        "PostgreSQL 9.x" {
                            $HashArguments.Add("PGInstance", $null)
                            $HashArguments.Add("WebOrDB", "DB")
                            $HashArguments.Add("Instance", "")
                            $HashArguments.Add("Database", "")
                            [System.Collections.ArrayList]$PgInstances = @(Get-PostgreSQLInstances)
                            foreach ($instance in $PgInstances) {
                                $HashArguments.PGInstance = $instance
                                $HashArguments.Instance = ($instance.Server + "-" + $instance.Port)
                                $HashArguments.Database = $instance.Database
                                Write-Log $STIGLog "----------------Writing CKL------------------" $LogComponent "Info" -OSPlatform $OSPlatform
                                Write-Ckl @HashArguments
                            }
                        }

                        Default {
                            Write-Ckl @HashArguments
                        }
                    }

                    If ($Item.PsModule) {
                        Write-Log $STIGLog "Removing scan module from memory" $LogComponent "Info" -OSPlatform $OSPlatform
                        Remove-Module $PsModule -Force
                    }
                }
            }
            Catch {
                Write-Log $STIGLog "    $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Log $STIGLog "    $($_.InvocationInfo.ScriptName)" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Log $STIGLog "    Line: $($_.InvocationInfo.ScriptLineNumber)" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Log $STIGLog "    $(($_.InvocationInfo.Line).Trim())" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Log $STIGLog "Continuing Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            }
        }

        Write-Log $STIGLog "----------------------------------" $LogComponent "Info" -OSPlatform $OSPlatform
        If ($GenerateOQE) {
            Switch ($OSPlatform) {
                "Windows" {
                    Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Generating Objective Quality Evidence (OQE) output" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
                    $CurrentMainStep++
                    Write-Log $STIGLog "Generating Objective Quality Evidence (OQE) output..." $LogComponent "Info" -OSPlatform $OSPlatform
                    Try {
                        If (-Not(Test-Path "$ResultsPath\OQE")) {
                            $null = New-Item -Path $ResultsPath -Name "OQE" -ItemType Directory
                        }

                        # Group Policy Report
                        Try {
                            Write-Log $STIGLog "Pulling Group Policy Report" $LogComponent "Info" -OSPlatform $OSPlatform
                            $GPResultFile = "GPResult_$(${env:computername})_$($Date).html"
                            If ($UserToProcess.SID -ne ".DEFAULT") {
                                Start-Process -FilePath GPResult.exe -ArgumentList "/USER $($UserToProcess.Username) /H $WorkingDir\$($GPResultFile)" -Wait -WindowStyle Hidden
                            }
                            Else {
                                Write-Log $STIGLog "    .DEFAULT selected as user to evaluate.  Group Policy results will not include user policies." $LogComponent "Warning" -OSPlatform $OSPlatform
                                Start-Process -FilePath GPResult.exe -ArgumentList "/SCOPE COMPUTER /H $WorkingDir\$($GPResultFile)" -Wait -WindowStyle Hidden
                            }
                            Get-ChildItem "$ResultsPath\OQE" -ErrorAction SilentlyContinue | Where-Object Name -like "GPResult*" | Remove-Item -Force -ErrorAction Stop # Clean previous GPResult files from output path
                            Copy-Item $WorkingDir\$($GPResultFile) -Destination "$ResultsPath\OQE"
                        }
                        Catch {
                            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }

                        # AppLocker Report
                        Try {
                            If ($AppLockerRequired -ne $true) {
                                Write-Log $STIGLog "Collecting AppLocker effective policy" $LogComponent "Info" -OSPlatform $OSPlatform
                                $AppLockerPolFile = "AppLockerPol_$(${env:computername})_$($Date).xml"
                                If (($PsVersionTable.PSVersion -join ".") -lt [Version]"7.0") {
                                    Import-Module AppLocker
                                }
                                Else {
                                    Import-Module AppLocker -SkipEditionCheck
                                }
                                Get-AppLockerPolicy -Effective -Xml -ErrorAction Stop | Out-File $WorkingDir\$($AppLockerPolFile) -Force -Encoding UTF8
                            }
                            Get-ChildItem "$ResultsPath\OQE" | Where-Object Name -like "AppLocker*" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction Stop # Clean previous AppLocker result files from output path
                            Copy-Item $WorkingDir\$($AppLockerPolFile) -Destination "$ResultsPath\OQE"
                        }
                        Catch {
                            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }

                        # Security Policy
                        Try {
                            If ($SecPolRequired -ne $true) {
                                Write-Log $STIGLog "Exporting security policy" $LogComponent "Info" -OSPlatform $OSPlatform
                                $SecPolFileName = "Evaluate-STIG_SecPol.ini"
                                Start-Process -FilePath secedit.exe -ArgumentList "/export /cfg $($WorkingDir)\$($SecPolFileName)" -Wait -WindowStyle Hidden
                            }
                            Get-ChildItem "$ResultsPath\OQE" -ErrorAction SilentlyContinue | Where-Object Name -like "SecPol*" | Remove-Item -Force -ErrorAction Stop # Clean previous Security Policy export files from output path
                            Copy-Item $WorkingDir\$($SecPolFileName) -Destination "$ResultsPath\OQE\SecPol_$(${env:computername})_$($Date).ini" -Force
                        }
                        Catch {
                            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        }
                    }
                    Catch {
                        Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                    }
                }
                "Linux" {
                    # Placeholder in the event there is something we want to provide as OQE for Linux systems.
                }
            }
        }

        # Cleanup
        If ($OSPlatform -eq "Windows") {
            # Clean up temporary user hive
            If ($STIGsToProcess.count -gt 0) {
                Write-Log $STIGLog "Remove temporary copy of user's registry hive HKLM:\SOFTWARE\Evaluate-STIG_UserHive" $LogComponent "Info" -OSPlatform $OSPlatform
                Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Finalizing and cleaning up" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
            }

            Try {
                If (Test-Path -Path Registry::HKLM\SOFTWARE\Evaluate-STIG_UserHive) {
                    Remove-Item -Path Registry::HKLM\SOFTWARE\Evaluate-STIG_UserHive -Recurse -Force
                }
            }
            Catch {
                Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
                Exit 10010001
            }
        }

        # Clean up extraneous previous checklists to preserve disk space
        Try {
            If (-Not($NoPrevious)) {
                Write-Log $STIGLog "Clean up extraneous checklist history" $LogComponent "Info" -OSPlatform $OSPlatform
                $CklHistory = Get-ChildItem -Path (Join-Path -Path $ResultsPath -ChildPath "Checklist" | Join-Path -ChildPath "Previous") -ErrorAction SilentlyContinue | Where-Object PSIsContainer -EQ $true | Select-Object Name, FullName | Sort-Object Name -Descending
                If ($CklHistory) {
                    $RecentPrevious = $CklHistory[0]
                    ForEach ($Folder in $CklHistory) {
                        If ($Folder.Name -ne $RecentPrevious.Name) {
                            Write-Log $STIGLog "Removing $($Folder.Name)" $LogComponent "Info" -OSPlatform $OSPlatform
                            Remove-Item $Folder.FullName -Recurse -Force -Confirm:$false
                        }
                    }
                }

                # Move non-applicable files to Previous folder
                Write-Log $STIGLog "Moving non-applicable files to Previous folder" $LogComponent "Info" -OSPlatform $OSPlatform
                $PreviousFolder = Get-Date -Format yyyy-MM-dd
                $PreviousPath = Join-Path -Path $ResultsPath -ChildPath "Checklist" | Join-Path -ChildPath "Previous" | Join-Path -ChildPath $PreviousFolder
                $AllItems = Get-ChildItem -Path $resultsPath -Recurse | Where-Object {(($_.Name -eq "Evaluate-STIG.log" -or $_.Name -like "SummaryReport.*" -or $_.Extension -eq ".ckl") -and $_.FullName -notlike "*Previous*")}
                ForEach ($Item in $AllItems) {
                    If ($Item.LastWriteTime -lt $EvalStart) {
                        If ($SelectSTIG -and $Item.Extension -eq ".ckl") {
                            # Do nothing.  With -SelectSTIG, we leave existing CKLs where they are.
                        }
                        Else {
                            If (-Not(Test-Path -Path $PreviousPath)) {
                                $null = New-Item -Path (Join-Path -Path $ResultsPath -ChildPath "Checklist") -Name (Join-Path -Path "Previous" -ChildPath $PreviousFolder) -ItemType Directory
                            }
                            Write-Log $STIGLog "Moving $($Item.Name) to $PreviousPath" $LogComponent "Info" -OSPlatform $OSPlatform
                            Move-Item -Path $Item.FullName -Destination $PreviousPath -Force
                        }
                    }
                }
            }
            Else {
                # Remove non-applicable files
                Write-Log $STIGLog "Removing non-applicable files" $LogComponent "Info" -OSPlatform $OSPlatform
                $AllItems = Get-ChildItem -Path $resultsPath -Recurse | Where-Object {(($_.Name -eq "Evaluate-STIG.log" -or $_.Name -like "SummaryReport.*" -or $_.Extension -eq ".ckl") -and $_.FullName -notlike "*Previous*")}
                ForEach ($Item in $AllItems) {
                    If ($Item.LastWriteTime -lt $EvalStart) {
                        If ($SelectSTIG -and $Item.Extension -eq ".ckl") {
                            # Do nothing.  With -SelectSTIG, we leave existing CKLs where they are.
                        }
                        Else {
                            Write-Log $STIGLog "Removing $($Item.Name)" $LogComponent "Info" -OSPlatform $OSPlatform
                            Remove-Item -Path $Item.FullName -Force
                        }
                    }
                }
            }
        }
        Catch {
            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Exit 10010001
        }

        # Create summary report
        Write-Log $STIGLog "Generating summary report" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Generating summary report" -PercentComplete ($CurrentMainStep / $TotalMainSteps * 100)
        $CurrentMainStep++
        Write-SummaryReport -CklPath (Join-Path -Path $ResultsPath -ChildPath "Checklist") -OutputPath $ResultsPath -ProcessedUser $UserToProcess.Username -Detail -OSPlatform $OSPlatform -ScanType $ScanType

        # Create Summary HTML
        $SummaryFile = Join-Path -Path $ResultsPath -ChildPath SummaryReport.xml
        [xml]$TempSR = New-Object xml

        $null = $TempSR.AppendChild($TempSR.CreateElement('Summaries'))
        $summary = New-Object xml
        $Summary.Load($SummaryFile)
        $ImportedSummary = $TempSR.ImportNode($Summary.DocumentElement, $true)
        $null = $TempSR.DocumentElement.AppendChild($ImportedSummary)

        $TempSR.Summaries.Summary.Checklists.Checklist | ForEach-Object {
            $CurrentScoreNode = $_.AppendChild($TempSR.CreateElement('CurrentScore'))
            $Currentnode = $_.SelectSingleNode("//Summary/Checklists/Checklist[STIG='$($_.STIG)']")
            $CurrentScore = ([int]$Currentnode.CAT_I.NotAFinding + [int]$Currentnode.CAT_II.NotAFinding + [int]$Currentnode.CAT_III.NotAFinding + [int]$Currentnode.CAT_I.Not_Applicable + [int]$Currentnode.CAT_II.Not_Applicable + [int]$Currentnode.CAT_III.Not_Applicable) / ([int]$Currentnode.CAT_I.Total + [int]$Currentnode.CAT_II.Total + [int]$Currentnode.CAT_III.Total)
            $CurrentScoreNode.SetAttribute("Score", $CurrentScore)
        }

        If ($PreviousPath) {
            if (Test-Path $PreviousPath) {
                $PreviousSummaryFile = Join-Path -Path $PreviousPath -ChildPath SummaryReport.xml
                $PreviousSummary = New-Object xml
                $PreviousSummary.Load($PreviousSummaryFile)

                $TempSR.Summaries.Summary.Checklists.Checklist | ForEach-Object {
                    $Previousnode = $PreviousSummary.SelectSingleNode("//Summary/Checklists/Checklist[STIG='$($_.STIG)']")
                    if ($Previousnode){
                        $PreviousScoreNode = $_.AppendChild($TempSR.CreateElement('PreviousScore'))
                        $PreviousScore = ([int]$Previousnode.CAT_I.NotAFinding + [int]$Previousnode.CAT_II.NotAFinding + [int]$Previousnode.CAT_III.NotAFinding + [int]$Previousnode.CAT_I.Not_Applicable + [int]$Previousnode.CAT_II.Not_Applicable + [int]$Previousnode.CAT_III.Not_Applicable) / ([int]$Previousnode.CAT_I.Total + [int]$Previousnode.CAT_II.Total + [int]$Previousnode.CAT_III.Total)
                        $PreviousScoreNode.SetAttribute("Delta", ((([float]($_.CurrentScore.Score) * 100) - ([float]($PreviousScore) * 100)))/100)
                    }
                }
            }
        }

        $TempSR.Save($(Join-Path -Path $WorkingDir -ChildPath TempSR.xml))

        $SummaryReportXLST = New-Object System.XML.Xsl.XslCompiledTransform
        $SummaryReportXLST.Load($(Join-Path -Path $PsScriptRoot -ChildPath "xml" | Join-Path -ChildPath SummaryReport.xslt))
        $SummaryReportXLST.Transform($(Join-Path -Path $WorkingDir -ChildPath TempSR.xml), $(Join-Path -Path $ResultsPath -ChildPath SummaryReport.html))

        # Apply tattoo
        If ($ApplyTattoo) {
            Write-Log $STIGLog "Applying Evaluate-STIG tattoo" $LogComponent "Info" -OSPlatform $OSPlatform
            Switch ($OSPlatform) {
                "Windows" {
                    # Mark registry with EvaluateStigVersion.  This can be used for SCCM detection method.
                    Try {
                        $RegistryPath = "HKLM:\SOFTWARE\Evaluate-STIG"
                        If (-Not(Test-Path -Path $RegistryPath)) {
                            $null = New-Item -Path $RegistryPath -Force
                        }
                        Write-Log $STIGLog "Creating 'Version' value under HKLM:\SOFTWARE\Evaluate-STIG" $LogComponent "Info" -OSPlatform $OSPlatform
                        $null = New-ItemProperty -Path $RegistryPath -Name Version -Value $ESVersion -PropertyType String -Force

                        Write-Log $STIGLog "Creating 'LastRun' value under HKLM:\SOFTWARE\Evaluate-STIG" $LogComponent "Info" -OSPlatform $OSPlatform
                        $null = New-ItemProperty -Path $RegistryPath -Name LastRun -Value $(Get-Date -Format FileDateTime) -PropertyType String -Force
                    }
                    Catch {
                        Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
                        Exit 10010001
                    }
                }
                "Linux" {
                    Try {
                        Write-Log $STIGLog "Creating 'Version' value in /etc/Evaluate-STIG" $LogComponent "Info" -OSPlatform $OSPlatform
                        "Version: $ESVersion" | Out-File /etc/Evaluate-STIG

                        Write-Log $STIGLog "Creating 'LastRun' value in /etc/Evaluate-STIG" $LogComponent "Info" -OSPlatform $OSPlatform
                        "LastRun: $((Get-Date -Format FileDateTime).Replace('T', ''))" | Out-File /etc/Evaluate-STIG -Append
                    }
                    Catch {
                        Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
                        Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
                        Exit 10010001
                    }
                }
            }
        }

        # Remove temporary files
        Write-Progress -Id $ProgressId -Activity $ProgressActivity -Status "Finalizing and cleaning up" -Completed
        Try {
            Write-Log $STIGLog "Removing temporary files" $LogComponent "Info" -OSPlatform $OSPlatform
            $TempFiles = Get-Item -Path $WorkingDir\* -Exclude Evaluate-STIG.log
            If ($TempFiles) {
                ForEach ($Item in $TempFiles) {
                    $null = Remove-Item -Path $Item.FullName -Recurse -ErrorAction Stop
                }
            }
        }
        Catch {
            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
        }

        $TotalCKLs = (Get-ChildItem -Path "$ResultsPath\Checklist" | Where-Object Extension -EQ '.ckl' | Measure-Object).Count
        $TimeToComplete = New-TimeSpan -Start $StartTime -End (Get-Date)
        $FormatedTime = "{0:c}" -f $TimeToComplete

        Write-Log $STIGLog "We're done!" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Total Time : $($FormatedTime)" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "Total CKLs in Results Directory : $($TotalCKLs)" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Log $STIGLog "==========[End Local Logging]==========" $LogComponent "Info" -OSPlatform $OSPlatform
        Write-Host "Done!" -ForegroundColor Green
        Write-Host "Total Time : $($FormatedTime)" -ForegroundColor Green
        Write-Host "Total CKLs in Results Directory : $($TotalCKLs)" -ForegroundColor Green
        Write-Host ""
        Write-Host "Results saved to " -ForegroundColor Green -NoNewline; Write-Host "$($ResultsPath)" -ForegroundColor Cyan
        Write-Host ""

        # Copy Evaluate-STIG.log to results path
        Try {
            Copy-Item $STIGLog -Destination $ResultsPath
        }
        Catch {
            Write-Log $STIGLog "ERROR: $($_.Exception.Message)" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Log $STIGLog "Terminated Processing" $LogComponent "Error" -OSPlatform $OSPlatform
            Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red -BackgroundColor Black
            Exit 10010001
        }
    }

    # Remove Evaluate-STIG modules from memory
    Get-Module | Where-Object Path -Like "$($PsScriptRoot)*" | Remove-Module -Force
}

# SIG # Begin signature block
# MIIL+QYJKoZIhvcNAQcCoIIL6jCCC+YCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCaiGlVUommOPma
# jSp+S4CCOIWHF+l0d2YXGG/pszsN16CCCTswggR6MIIDYqADAgECAgQDAgTXMA0G
# CSqGSIb3DQEBCwUAMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVy
# bm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0Qg
# SUQgQ0EtNTkwHhcNMjAwNzE1MDAwMDAwWhcNMjUwNDAyMTMzODMyWjBpMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMRYwFAYDVQQDEw1DUy5OU1dDQ0Qu
# MDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2/Z91ObHZ009DjsX
# ySa9T6DbT+wWgX4NLeTYZwx264hfFgUnIww8C9Mm6ht4mVfo/qyvmMAqFdeyhXiV
# PZuhbDnzdKeXpy5J+oxtWjAgnWwJ983s3RVewtV063W7kYIqzj+Ncfsx4Q4TSgmy
# ASOMTUhlzm0SqP76zU3URRj6N//NzxAcOPLlfzxcFPMpWHC9zNlVtFqGtyZi/STj
# B7ed3BOXmddiLNLCL3oJm6rOsidZstKxEs3I1llWjsnltn7fR2/+Fm+roWrF8B4z
# ekQOu9t8WRZfNohKoXVtVuwyUAJQF/8kVtIa2YyxTUAF9co9qVNZgko/nx0gIdxS
# hxmEvQIDAQABo4IBNzCCATMwHwYDVR0jBBgwFoAUdQmmFROuhzz6c5QA8vD1ebmy
# chQwQQYDVR0fBDowODA2oDSgMoYwaHR0cDovL2NybC5kaXNhLm1pbC9jcmwvRE9E
# SURDQV81OV9OQ09ERVNJR04uY3JsMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSAEDzAN
# MAsGCWCGSAFlAgELKjAdBgNVHQ4EFgQUVusXc6nN92xmQ3XNN+/76hosJFEwZQYI
# KwYBBQUHAQEEWTBXMDMGCCsGAQUFBzAChidodHRwOi8vY3JsLmRpc2EubWlsL3Np
# Z24vRE9ESURDQV81OS5jZXIwIAYIKwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2Eu
# bWlsMB8GA1UdJQQYMBYGCisGAQQBgjcKAw0GCCsGAQUFBwMDMA0GCSqGSIb3DQEB
# CwUAA4IBAQBCSdogBcOfKqyGbKG45lLicG1LJ2dmt0Hwl7QkKrZNNEDh2Q2+uzB7
# SRmADtSOVjVf/0+1B4jBoyty90WL52rMPVttb8tfm0f/Wgw6niz5WQZ+XjFRTFQa
# M7pBNU54vI3bH4MFBTXUOEoSr0FELFQaByUWfWKrGLnEqYtpDde5FZEYKRv6td6N
# ZH7m5JOiCfEK6gun3luq7ckvx5zIXjr5VKhp+S0Aai3ZR/eqbBZ0wcUF3DOYlqVs
# LiPT0jWompwkfSnxa3fjNHD+FKvd/7EMQM/wY0vZyIObto3QYrLru6COAyY9cC/s
# Dj+R4K4392w1LWdo3KrNzkCFMAX6j/bWMIIEuTCCA6GgAwIBAgICAwUwDQYJKoZI
# hvcNAQELBQAwWzELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVu
# dDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFjAUBgNVBAMTDURvRCBSb290
# IENBIDMwHhcNMTkwNDAyMTMzODMyWhcNMjUwNDAyMTMzODMyWjBaMQswCQYDVQQG
# EwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAK
# BgNVBAsTA1BLSTEVMBMGA1UEAxMMRE9EIElEIENBLTU5MIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAzBeEny3BCletEU01Vz8kRy8cD2OWvbtwMTyunFaS
# hu+kIk6g5VRsnvbhK3Ho61MBmlGJc1pLSONGBhpbpyr2l2eONAzmi8c8917V7Bpn
# JZvYj66qGRmY4FXX6UZQ6GdALKKedJKrMQfU8LmcBJ/LGcJ0F4635QocGs9UoFS5
# hLgVyflDTC/6x8EPbi/JXk6N6iod5JIAxNp6qW/5ZBvhiuMo19oYX5LuUy9B6W7c
# A0cRygvYcwKKYK+cIdBoxAj34yw2HJI8RQt490QPGClZhz0WYFuNSnUJgTHsdh2V
# NEn2AEe2zYhPFNlCu3gSmOSp5vxpZWbMIQ8cTv4pRWG47wIDAQABo4IBhjCCAYIw
# HwYDVR0jBBgwFoAUbIqUonexgHIdgXoWqvLczmbuRcAwHQYDVR0OBBYEFHUJphUT
# roc8+nOUAPLw9Xm5snIUMA4GA1UdDwEB/wQEAwIBhjBnBgNVHSAEYDBeMAsGCWCG
# SAFlAgELJDALBglghkgBZQIBCycwCwYJYIZIAWUCAQsqMAsGCWCGSAFlAgELOzAM
# BgpghkgBZQMCAQMNMAwGCmCGSAFlAwIBAxEwDAYKYIZIAWUDAgEDJzASBgNVHRMB
# Af8ECDAGAQH/AgEAMAwGA1UdJAQFMAOAAQAwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9EUk9PVENBMy5jcmwwbAYIKwYBBQUHAQEE
# YDBeMDoGCCsGAQUFBzAChi5odHRwOi8vY3JsLmRpc2EubWlsL2lzc3VlZHRvL0RP
# RFJPT1RDQTNfSVQucDdjMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1p
# bDANBgkqhkiG9w0BAQsFAAOCAQEAOQUb0g6nPvWoc1cJ5gkhxSyGA3bQKu8HnKbg
# +vvMpMFEwo2p30RdYHGvA/3GGtrlhxBqAcOqeYF5TcXZ4+Fa9CbKE/AgloCuTjEY
# t2/0iaSvdw7y9Vqk7jyT9H1lFIAQHHN3TEwN1nr7HEWVkkg41GXFxU01UHfR7vgq
# TTz+3zZL2iCqADVDspna0W5pF6yMla6gn4u0TmWu2SeqBpctvdcfSFXkzQBZGT1a
# D/W2Fv00KwoQgB2l2eiVk56mEjN/MeI5Kp4n57mpREsHutP4XnLQ01ZN2qgn+844
# JRrzPQ0pazPYiSl4PeI2FUItErA6Ob/DPF0ba2y3k4dFkUTApzGCAhQwggIQAgEB
# MGIwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoG
# A1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS01OQIE
# AwIE1zANBglghkgBZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAA
# MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgor
# BgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEiBCCgQ+dljU/MMXBf2ij4zTszr2RZQrxt
# EsH2DRJoo26NKjANBgkqhkiG9w0BAQEFAASCAQAwH5CkUEzqItEJ5IvDV6BTc2NZ
# eBwsKzPMNMEANmNeQ4y/xmW25goFguEzJZ4piomDcdTyNF4z4jHvyK3P/ma7FGy5
# 8JiLNmZzdYKtbOP+uhs2oMtEFAuofxfithCt9hA9EKeUBJf73VLhDWDRB5MB0O2P
# EqnwQEL0Gnyr09nZ9c8hlNtnCwyBZ6FD6Ddwv0tjkbzyyY4bR2SrF1WA3QPu5xWD
# f9sQlqPjaqkeK0Zv2xYV9DgZlAPwPBPFho4lfw4tAvjemuC/gWCEHogSTeljqxIY
# 3qXjskBoGsNqMOVETBciOh/hwWWGTS/ICRY5N1m9++xy8rm3IBPblGckr0tr
# SIG # End signature block
